package com.example.asma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
