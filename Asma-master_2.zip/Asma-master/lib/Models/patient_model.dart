class PatientModel {
  late String name;
  late String email;
  late String password;
  late String phone;
  late String uId;
  late bool hasMedicine = false;
  late bool hasDevice = false;

  PatientModel(
      {required this.name,
      required this.email,
      required this.password,
      required this.phone,
      required this.uId});

  toMap() {
    return {
      "name": name,
      "email": email,
      "password": password,
      "phone": phone,
      "uId": uId,
      "hasMedicine": hasMedicine,
      "hasDevice": hasDevice,
    };
  }

  PatientModel.fromJson(Map<String, dynamic> data) {
    name = data["name"]!;
    email = data["email"]!;
    password = data["password"]!;
    uId = data["uId"]!;
    phone = data["phone"]!;
    hasMedicine = data["hasMedicine"]!;
    hasDevice = data["hasDevice"]!;
  }
}
