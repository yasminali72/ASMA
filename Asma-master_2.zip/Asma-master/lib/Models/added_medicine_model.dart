import 'package:asma/Models/reminder_model.dart';

class AddedMedicineModel {
  late int medicineId;
  late double remainingUsages;
  late ReminderModel? reminderModel;

  AddedMedicineModel(
      {required this.medicineId,
      required this.remainingUsages,
      required this.reminderModel});

  AddedMedicineModel.fromJson(Map<String, dynamic> data) {
    medicineId = data["medicineId"];
    remainingUsages = data["remainingUsages"];
    reminderModel =data["reminderModel"]== null? null: ReminderModel.fromJson(data["reminderModel"]);
  }

  toMap() {
    return {
      "medicineId": medicineId,
      "remainingUsages": remainingUsages,
      "reminderModel": reminderModel?.toMap(),
    };
  }
}
