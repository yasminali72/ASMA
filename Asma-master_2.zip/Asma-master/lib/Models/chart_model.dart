class ChartModel {
  final String date;
  final int value;

  ChartModel({required this.date, required this.value});
}
