class SensorsModel {
  final int? gasConcentration;
  final int? temperature;
  final int? dustDensity;
  final int? humidity;
  final int? pm10;
  final int? pm25;
  final int? heartRate;
  final int? sp02;

  SensorsModel(
      {required this.gasConcentration,
      required this.temperature,
      required this.dustDensity,
      required this.humidity,
      required this.pm10,
      required this.pm25,
      required this.heartRate,
      required this.sp02});
}
