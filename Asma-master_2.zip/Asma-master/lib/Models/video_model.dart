class VideoModel {
  final String title;
  final String description;
  final String id;

  VideoModel(
      {required this.title, required this.description, required this.id});
}
