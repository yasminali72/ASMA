class ReminderModel {
  late bool fullScreen;
  late bool sound;
  late bool vibration;
  late bool silent;
  late List<dynamic> medicineTimes;

  ReminderModel({
    required this.fullScreen,
    required this.sound,
    required this.vibration,
    required this.silent,
    required this.medicineTimes,
  });

  ReminderModel.fromJson(Map<String, dynamic> data) {
    fullScreen = data["fullScreen"]!;
    sound = data["sound"]!;
    vibration = data["vibration"]!;
    silent = data["silent"]!;
    medicineTimes = data["medicineTimes"];
  }

  toMap() {
    return {
      "fullScreen": fullScreen,
      "sound": sound,
      "vibration": vibration,
      "silent": silent,
      "medicineTimes": medicineTimes,
    };
  }
}
