class MedicineModel {
  late int id;
  late String name;
  late String info;
  late String image;
  late String counterSize;

  MedicineModel({
    required this.id,
    required this.name,
    required this.info,
    required this.image,
    required this.counterSize,
  });
}
