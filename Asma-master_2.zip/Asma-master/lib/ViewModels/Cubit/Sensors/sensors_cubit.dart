import 'package:asma/Models/chart_model.dart';
import 'package:asma/Models/sensors_model.dart';
import 'package:asma/ViewModels/Cubit/Sensors/sensors_states.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SensorsCubit extends Cubit<SensorsStates> {
  SensorsCubit() : super(SensorsInit());

  static SensorsCubit get(BuildContext context) {
    return BlocProvider.of(context);
  }

  FirebaseDatabase _database = FirebaseDatabase.instance;
  late SensorsModel sensorsModel;
  loadSensorsData() async {
    emit(SensorsDataLoading());
    sensorsModel = SensorsModel(
        gasConcentration: await getSensorItemData("AirQuality"),
        temperature: await getSensorItemData("temperature"),
        dustDensity: await getSensorItemData("dustDensity"),
        humidity: await getSensorItemData("humidity"),
        pm10: await getSensorItemData("pm10"),
        heartRate: await getSensorItemData("HeartRate"),
        sp02: await getSensorItemData("SpO2"),
        pm25: await getSensorItemData("pm25"));
    emit(SensorsDataSuccess());
  }

  getSensorItemData(String sensorItem) async {
    int? sensorData;
    await _database.ref("datasensors/$sensorItem").get().then((value) {
      List<DataSnapshot> data = value.children.toList().reversed.toList();
      if (sensorItem == "humidity")
        getHumidityFigureData(data);
      else if (sensorItem == "dustDensity")
        getDustFigureData(data);
      else if (sensorItem == "temperature")
        getTemperatureFigureData(data);
      else if (sensorItem == "AirQuality") getAirFigureData(data);
      sensorData = double.parse(data.first.value.toString()).toInt();
    });
    return sensorData;
  }

  List<ChartModel> humidityCharts = [];
  getHumidityFigureData(List<DataSnapshot> data) {
    for (int i = 0; i < 10; i++) {
      try {
        humidityCharts.add(ChartModel(
            date: i.toString(), value: int.parse(data[i].value.toString())));
      } catch (_) {
        humidityCharts.add(ChartModel(date: i.toString(), value: 0));
      }
    }
  }

  List<ChartModel> airCharts = [];
  getAirFigureData(List<DataSnapshot> data) {
    for (int i = 0; i < 10; i++) {
      try {
        airCharts.add(ChartModel(
            date: i.toString(), value: int.parse(data[i].value.toString())));
      } catch (_) {
        airCharts.add(ChartModel(date: i.toString(), value: 0));
      }
    }
  }

  List<ChartModel> dustCharts = [];
  getDustFigureData(List<DataSnapshot> data) {
    for (int i = 0; i < 10; i++) {
      try {
        dustCharts.add(ChartModel(
            date: i.toString(), value: int.parse(data[i].value.toString())));
      } catch (_) {
        dustCharts.add(ChartModel(date: i.toString(), value: 0));
      }
    }
  }

  List<ChartModel> temperatureCharts = [];
  getTemperatureFigureData(List<DataSnapshot> data) {
    for (int i = 0; i < 10; i++) {
      try {
        temperatureCharts.add(ChartModel(
            date: i.toString(), value: int.parse(data[i].value.toString())));
      } catch (_) {
        temperatureCharts.add(ChartModel(date: i.toString(), value: 0));
      }
    }
  }
}
