abstract class SensorsStates {}

class SensorsInit extends SensorsStates {}

class SensorsDataLoading extends SensorsStates {}

class SensorsDataSuccess extends SensorsStates {}
