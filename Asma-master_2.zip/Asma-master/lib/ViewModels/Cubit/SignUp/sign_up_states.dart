abstract class SignUpStates {}

class SignUpInit extends SignUpStates {}

class SignUpLoading extends SignUpStates {}

class SignUpSuccess extends SignUpStates {}

class SignUpError extends SignUpStates {
  final String error;

  SignUpError(this.error);
}

class PasswordVisibilityChanged extends SignUpStates {}
