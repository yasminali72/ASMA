import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../Models/patient_model.dart';
import '../../../ViewModels/Constants/constants_class.dart';
import 'sign_up_states.dart';

class SignUpCubit extends Cubit<SignUpStates> {
  SignUpCubit() : super(SignUpInit());

  static SignUpCubit get(BuildContext context) => BlocProvider.of(context);

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  final FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;

  PatientModel? patient;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  final formKey = GlobalKey<FormState>();
  void signUp() {
    emit(SignUpLoading());
    _firebaseAuth
        .createUserWithEmailAndPassword(
            email: emailController.text, password: passwordController.text)
        .then((value) async {
      await createUser(uId: value.user!.uid);
      ConstantsClass.setUId(value.user!.uid);
      emit(SignUpSuccess());
    }).catchError((err) {
      String message = "Error";
      FirebaseAuthException e = err;
      if (e.code == "email-already-in-use") {
        message = "Email already In Use by another Account";
      } else if (e.code == "invalid-email") {
        message = "Invalid Email";
      } else if (e.code == "weak-password") {
        message = "Weak Password";
      }
      emit(SignUpError(message));
    });
  }

  createUser({
    required String uId,
  }) async {
    patient = PatientModel(
        name: nameController.text,
        email: emailController.text,
        password: passwordController.text,
        uId: uId,
        phone: phoneController.text);
    await _firebaseFirestore
        .collection('Patients')
        .doc(uId)
        .set(patient!.toMap());
  }

  bool isPasswordVisible = true;
  changePasswordVisibility() {
    isPasswordVisible = !isPasswordVisible;
    emit(PasswordVisibilityChanged());
  }
}
