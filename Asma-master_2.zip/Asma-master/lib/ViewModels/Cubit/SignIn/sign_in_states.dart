abstract class SignInStates {}

class SignInInit extends SignInStates {}

class SignInLoading extends SignInStates {}

class SignInSuccess extends SignInStates {}

class SignInError extends SignInStates {
  final String error;

  SignInError(this.error);
}

class SignOutLoading extends SignInStates {}

class SignOutSuccess extends SignInStates {}

class PasswordVisibilityChanged extends SignInStates {}
