import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../Models/patient_model.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'sign_in_states.dart';

class SignInCubit extends Cubit<SignInStates> {
  SignInCubit() : super(SignInInit());

  static SignInCubit get(BuildContext context) => BlocProvider.of(context);

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  bool isPasswordVisible = true;
  changePasswordVisibility() {
    isPasswordVisible = !isPasswordVisible;
    emit(PasswordVisibilityChanged());
  }

  void signIn() {
    emit(SignInLoading());
    _firebaseAuth
        .signInWithEmailAndPassword(
            email: emailController.text, password: passwordController.text)
        .then((value) async {
      ConstantsClass.setUId(value.user!.uid);
      await getCurrentPatient();
      emit(SignInSuccess());
    }).catchError((err) {
      String message = "Error";
      FirebaseAuthException e = err;
      if (e.code == "user-not-found") {
        message = "No user found with this email";
      } else if (e.code == "invalid-email") {
        message = "Invalid Email";
      } else if (e.code == "wrong-password") {
        message = "Incorrect Password";
      }
      emit(SignInError(message));
    });
  }

  void signOut() async {
    emit(SignOutLoading());
    await _firebaseAuth.signOut();
    ConstantsClass.setUId(null);
    emit(SignOutSuccess());
  }

  PatientModel? patient;
  Future getCurrentPatient() async {
    if (ConstantsClass.getUId() == null) return;
    await FirebaseFirestore.instance
        .collection("Patients")
        .doc(ConstantsClass.getUId())
        .get()
        .then((value) => patient = PatientModel.fromJson(value.data()!));
  }
}
