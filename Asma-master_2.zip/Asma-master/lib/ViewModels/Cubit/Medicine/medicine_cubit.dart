import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/Models/added_medicine_model.dart';
import 'package:asma/Models/chart_model.dart';
import 'package:asma/Models/patient_model.dart';
import 'package:asma/Models/reminder_model.dart';
import 'package:intl/intl.dart';
import '../../../Helpers/work_manager_helper.dart';
import '../../../ViewModels/Constants/constants_class.dart';
import '../../../Models/medicine_model.dart';
import 'medicine_states.dart';
import 'package:flutter/material.dart';

class MedicineCubit extends Cubit<MedicineStates> {
  MedicineCubit() : super(MedicineInit());

  static MedicineCubit get(BuildContext context) => BlocProvider.of(context);

  final FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;

  final TextEditingController searchController = TextEditingController();

  List<MedicineModel> getMedicine() {
    List<MedicineModel> medicines = ConstantsClass.getMedicines();
    if (searchController.text.isEmpty) {
      return medicines;
    } else {
      return medicines
          .where((element) => element.name.contains(searchController.text))
          .toList();
    }
  }

  searchMedicine() {
    emit(MedicineSearch());
  }

  double remainingMedicine = 0;

  updateRemainingMedicine(double val) {
    remainingMedicine = val;
    emit(RemainingMedicineUpdated());
  }

  int numberOfDoses = 0;

  dosesIncrement() {
    numberOfDoses++;
    dosesReminder.add(const TimeOfDay(hour: 0, minute: 0));
    emit(MedicineDosesChanged());
  }

  dosesDecrement() {
    if (numberOfDoses > 0) {
      numberOfDoses--;
      dosesReminder.removeLast();
      emit(MedicineDosesChanged());
    }
  }

  List<TimeOfDay> dosesReminder = [];

  addDosesReminder(int index, TimeOfDay? time) {
    if (time == null) return;
    dosesReminder[index] = time;
    emit(MedicineDosesTimeSelected());
  }

  String getTimeOfDate(TimeOfDay timeOfDay, BuildContext context) {
    return MaterialLocalizations.of(context).formatTimeOfDay(timeOfDay);
  }

  bool fullScreen = false;
  bool sound = false;
  bool vibration = false;
  bool silent = false;

  setDosesSettingValues(bool val, String type) {
    if (type == "Full Screen") {
      fullScreen = val;
    } else if (type == "Sound") {
      sound = val;
    } else if (type == "Vibration") {
      vibration = val;
    } else {
      silent = val;
    }
    emit(MedicineDosesSetting());
  }

  int homeTopButtonIndex = 0;

  updateHomeTopButtonIndex(int index) {
    homeTopButtonIndex = index;
    emit(UpdateHomeTopButtonIndex());
  }

  List<String> days = [];

  int dayButtonIndex = 6;

  updateDayButtonIndex(int index) {
    dayButtonIndex = index;
    emit(UpdateDayButtonIndex());
  }

  DateTime now =
      DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);

  List<DateTime> weekDays = [];
  void getCurrentWeekDays() {
    weekDays.clear();
    for (int i = 6; i >= 0; i--) {
      DateTime dayDate = now.subtract(Duration(days: i));
      weekDays.add(dayDate);
      days.add(getDayName(dayDate));
    }
  }

  String getDayName(DateTime dateTime) {
    return DateFormat.E().format(dateTime).substring(0, 2).toUpperCase();
  }

  DateTime getDayOfCurrentIndex() {
    return weekDays[dayButtonIndex];
  }

  int chartsTopButtonIndex = 0;

  updateChartsTopButtonIndex(int index) {
    chartsTopButtonIndex = index;
    emit(UpdateChartsTopButtonIndex());
  }

  int videosTopButtonIndex = 0;

  updateVideosTopButtonIndex(int index) {
    videosTopButtonIndex = index;
    emit(UpdateVideosTopButtonIndex());
  }

  bool isAllRemindersSelected() {
    int count = 0;
    for (var element in dosesReminder) {
      if (element == const TimeOfDay(hour: 0, minute: 0)) {
        ++count;
      }
    }
    if (dosesReminder.isEmpty || count > 1 || numberOfDoses < 1) {
      return false;
    } else {
      return true;
    }
  }

  final Map<String, AddedMedicineModel> _selectedMedicine = {};

  final Map<String, ReminderModel> _reminderModel = {};
  addReminder(String type, BuildContext context) {
    List<String> times = [];
    for (var element in dosesReminder) {
      times.add(getTimeOfDate(element, context));
    }

    _reminderModel.addAll({
      type: ReminderModel(
        fullScreen: fullScreen,
        sound: sound,
        vibration: vibration,
        silent: silent,
        medicineTimes: times,
      )
    });
    dosesReminder.clear();
    numberOfDoses = 0;
    fullScreen = sound = vibration = silent = false;
    emit(ReminderAdded());
  }

  addSelectedMedicine(String medicineType, int medicineId) {
    _selectedMedicine.addAll({
      medicineType: AddedMedicineModel(
        remainingUsages: remainingMedicine.toInt().toDouble(),
        medicineId: medicineId,
        reminderModel: _reminderModel[medicineType],
      )
    });
    emit(PatientMedicineAdded());
  }

  bool isPlannedAdded(String type) {
    return _reminderModel[type] != null;
  }

  bool isMedicineAdded(String type) {
    return _selectedMedicine[type] != null;
  }

  connectDeviceAndAddMedicine(bool addDevice, PatientModel patientModel) async {
    emit(MedicineDeviceLoading());
    if (addDevice) {
      if (deviceController.text.isEmpty) {
        emit(MedicineDeviceError());
        return;
      }
      await connectDevice();
    }
    await addMedicine();
    await updatePatient(patientModel, addDevice);
    deviceController.clear();
    emit(MedicineDeviceSuccess());
  }

  final TextEditingController deviceController = TextEditingController();

  connectDevice() async {
    await _firebaseFirestore
        .collection("Serials")
        .doc(ConstantsClass.getUId())
        .set({"serial": deviceController.text});
  }

  addMedicine() async {
    await _firebaseFirestore
        .collection("Medicine")
        .doc(ConstantsClass.getUId())
        .set({
      "regular": _selectedMedicine["regular"]?.toMap(),
      "rescue": _selectedMedicine["rescue"]?.toMap(),
    });
    _selectedMedicine.clear();
    _reminderModel.clear();
  }

  updatePatient(PatientModel patientModel, bool addDevice) async {
    if (addDevice == true) {
      patientModel.hasDevice = addDevice;
    }
    patientModel.hasMedicine = true;
    await _firebaseFirestore
        .collection("Patients")
        .doc(patientModel.uId)
        .update(patientModel.toMap());
  }

  AddedMedicineModel? regularPatientMedicine;
  AddedMedicineModel? rescuePatientMedicine;
  getPatientMedicine(PatientModel? patientModel) {
    if (patientModel != null && patientModel.hasMedicine) {
      emit(PatientMedicineLoading());
      _firebaseFirestore
          .collection("Medicine")
          .doc(ConstantsClass.getUId())
          .snapshots()
          .listen((value) {
        regularPatientMedicine =
            AddedMedicineModel.fromJson(value.data()!["regular"]);
        rescuePatientMedicine =
            AddedMedicineModel.fromJson(value.data()!["rescue"]);
        emit(PatientMedicineLoaded());
        WorkManagerHelper.startTask(
            regularPatientMedicine!.reminderModel!.medicineTimes);
      });
    }
  }

  MedicineModel getLocalMedicineById(int id) {
    return ConstantsClass.getMedicines()
        .firstWhere((element) => element.id == id);
  }

  MedicineModel getRegularMedicine() {
    return getLocalMedicineById(regularPatientMedicine!.medicineId);
  }

  MedicineModel getRescueMedicine() {
    return getLocalMedicineById(rescuePatientMedicine!.medicineId);
  }

  StreamSubscription? _regularSubscription;
  List<Map<String, dynamic>> regularDoses = [];
  getRegularDoses() {
    _regularSubscription = _firebaseFirestore
        .collection("Regular")
        .where("id", isGreaterThanOrEqualTo: Timestamp.fromDate(weekDays[0]))
        .where("uId", isEqualTo: ConstantsClass.getUId())
        .snapshots()
        .listen((event) {
      regularDoses.clear();
      for (var element in event.docs) {
        regularDoses.add(element.data());
      }
      emit(GetRegularDoses());
    });
  }

  List<Map<String, dynamic>> rescueDoses = [];
  StreamSubscription? _rescueSubscription;
  getRescueDoses() {
    _rescueSubscription = _firebaseFirestore
        .collection("Rescue")
        .where("id", isGreaterThanOrEqualTo: Timestamp.fromDate(weekDays[0]))
        .where("uId", isEqualTo: ConstantsClass.getUId())
        .snapshots()
        .listen((event) {
      rescueDoses.clear();
      for (var element in event.docs) {
        rescueDoses.add(element.data());
      }
      emit(GetRescueDoses());
    });
  }

  getDoses(PatientModel? patientModel) {
    if (patientModel != null && patientModel.hasMedicine) {
      getCurrentWeekDays();
      getRescueDoses();
      getRegularDoses();
    }
  }

  increaseRegularDoses() async {
    if (regularPatientMedicine!.reminderModel!.medicineTimes.length ==
        getTodayRegularDosesLocal()) {
      emit(IncreaseDosesError());
      return;
    }
    DateTime dateWithTime = DateTime.now();
    await _firebaseFirestore.collection("Regular").add({
      "id": Timestamp.fromDate(now),
      "time": DateFormat('h:mm a').format(dateWithTime),
      "uId": ConstantsClass.getUId()
    });
    await updateMedicineRegularUsages();
    emit(IncreaseDosesSuccess());
  }

  increaseRescueDoses() async {
    DateTime dateWithTime = DateTime.now();
    await _firebaseFirestore.collection("Rescue").add({
      "id": Timestamp.fromDate(now),
      "time": DateFormat('h:mm a').format(dateWithTime),
      "uId": ConstantsClass.getUId()
    });
    await updateMedicineRescueUsages();
    emit(IncreaseDosesSuccess());
  }

  Future increaseDoses(String label) async {
    emit(IncreaseDosesLoading());
    if (label == "Regular") {
      await increaseRegularDoses();
    } else {
      await increaseRescueDoses();
    }
  }

  updateMedicineRegularUsages() async {
    --regularPatientMedicine?.remainingUsages;
    await _firebaseFirestore
        .collection("Medicine")
        .doc(ConstantsClass.getUId())
        .get()
        .then((value) {
      value.reference.update({
        "regular": regularPatientMedicine?.toMap(),
        "rescue": value.data()!["rescue"]
      });
    });
  }

  updateMedicineRescueUsages() async {
    --rescuePatientMedicine?.remainingUsages;
    await _firebaseFirestore
        .collection("Medicine")
        .doc(ConstantsClass.getUId())
        .get()
        .then((value) {
      value.reference.update({
        "regular": value.data()!["regular"],
        "rescue": rescuePatientMedicine?.toMap()
      });
    });
  }

  List getRegularDosesLocal() {
    return regularDoses
        .where((element) =>
            element["id"] == Timestamp.fromDate(weekDays[dayButtonIndex]))
        .toList();
  }

  int getTodayRegularDosesLocal() {
    return regularDoses
        .where((element) => element["id"] == Timestamp.fromDate(now))
        .length;
  }

  int getTodayRescueDosesLocal() {
    return rescueDoses
        .where((element) => element["id"] == Timestamp.fromDate(now))
        .length;
  }

  String getNightUsages() {
    List<String> nightDoses = [];
    for (var element in rescueDoses) {
      if (element["time"].split(" ").last == "PM") {
        nightDoses.add(element.values.first.split(" ").first);
      }
    }

    return nightDoses.length.toString();
  }

  String getDayUsages() {
    List<String> dayDoses = [];
    for (var element in rescueDoses) {
      if (element["time"].split(" ").last == "AM") {
        dayDoses.add(element.values.first.split(" ").first);
      }
    }

    return dayDoses.length.toString();
  }

  int getRescueOfSpecificDay(DateTime dateTime) {
    try {
      return rescueDoses
          .where((element) => element["id"] == Timestamp.fromDate(dateTime))
          .length;
    } catch (_) {
      return 0;
    }
  }

  int getRegularOfSpecificDay(DateTime dateTime) {
    try {
      return regularDoses
          .where((element) => element["id"] == Timestamp.fromDate(dateTime))
          .length;
    } catch (_) {
      return 0;
    }
  }

  List<ChartModel> getRescueFigureData() {
    List<ChartModel> rescueFigureData = [];
    int i = 0;
    for (var value in weekDays) {
      int dosesTimes = getRescueOfSpecificDay(value);
      rescueFigureData.add(ChartModel(date: days[i], value: dosesTimes));
      i++;
    }
    return rescueFigureData;
  }

  List<ChartModel> getRegularFigureData() {
    List<ChartModel> regularFigureData = [];
    int i = 0;
    for (var value in weekDays) {
      int dayDoses = getRegularOfSpecificDay(value);
      regularFigureData.add(ChartModel(date: days[i], value: dayDoses));
      i++;
    }
    return regularFigureData;
  }

  List<ChartModel> getFigureData(bool regular) {
    return regular ? getRegularFigureData() : getRescueFigureData();
  }

  int getDosesFigureCount(bool regular) {
    return regular ? getRegularMedicineTime() : getRescueMedicineTime();
  }

  getRegularMedicineTime() {
    int regularMedicineTimes = 0;
    getRegularFigureData().forEach((element) {
      regularMedicineTimes += element.value;
    });
    return regularMedicineTimes;
  }

  getRescueMedicineTime() {
    int rescueMedicineTimes = 0;
    getRescueFigureData().forEach((element) {
      rescueMedicineTimes += element.value;
    });
    return rescueMedicineTimes;
  }

  List getRescueDosesLocal() {
    return rescueDoses
        .where((element) =>
            element["id"] == Timestamp.fromDate(weekDays[dayButtonIndex]))
        .toList();
  }

  String getRegularReminderTime() {
    String reminderTimes = "";
    for (var element in regularPatientMedicine!.reminderModel!.medicineTimes) {
      reminderTimes = "$reminderTimes$element";
      if (element !=
          regularPatientMedicine!.reminderModel!.medicineTimes.last) {
        reminderTimes = "$reminderTimes, ";
      }
    }
    return reminderTimes;
  }

  String getRecueUsageTime() {
    String rescueTimes = "";
    for (var value in getRescueDosesLocal()) {
      rescueTimes = "$rescueTimes ${value["time"]}";
      if (value != getRescueDosesLocal().last) {
        rescueTimes = "$rescueTimes, ";
      }
    }
    return rescueTimes.isEmpty ? "No used" : rescueTimes;
  }

  String getRegularUsageTime() {
    String regularTimes = "";
    for (var value in getRegularDosesLocal()) {
      regularTimes = "$regularTimes ${value["time"]}";
      if (value != getRegularDosesLocal().last) {
        regularTimes = "$regularTimes, ";
      }
    }
    return regularTimes.isEmpty ? "No used" : regularTimes;
  }

  updatePatientMedicine() {}

  closeStreams() async {
    await _regularSubscription?.cancel();
    await _rescueSubscription?.cancel();
    weekDays.clear();
  }
}
