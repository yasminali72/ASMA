abstract class MedicineStates {}

class MedicineInit extends MedicineStates {}

class MedicineSearch extends MedicineStates {}

class RemainingMedicineUpdated extends MedicineStates {}

class MedicineDosesChanged extends MedicineStates {}

class MedicineDosesTimeSelected extends MedicineStates {}

class PatientMedicineAdded extends MedicineStates {}

class ReminderAdded extends MedicineStates {}

class MedicineDosesSetting extends MedicineStates {}

class UpdateHomeTopButtonIndex extends MedicineStates {}

class UpdateChartsTopButtonIndex extends MedicineStates {}

class UpdateVideosTopButtonIndex extends MedicineStates {}

class UpdateDayButtonIndex extends MedicineStates {}

class MedicineDeviceLoading extends MedicineStates {}

class MedicineDeviceError extends MedicineStates {}

class MedicineDeviceSuccess extends MedicineStates {}

class PatientMedicineLoading extends MedicineStates {}

class PatientMedicineLoaded extends MedicineStates {}

class IncreaseDosesLoading extends MedicineStates {}

class IncreaseDosesSuccess extends MedicineStates {}

class IncreaseDosesError extends MedicineStates {}

class GetRegularDoses extends MedicineStates {}

class GetRescueDoses extends MedicineStates {}
