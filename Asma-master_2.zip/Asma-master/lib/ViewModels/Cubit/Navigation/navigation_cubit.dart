import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/Views/ChartsScreen/charts_screen.dart';
import 'package:asma/Views/HomeScreen/home_screen.dart';
import 'package:asma/Views/MedicineScreen/medicine_screen.dart';
import 'package:asma/Views/VideosScreen/videos_screen.dart';
import 'navigation_states.dart';

class NavigationCubit extends Cubit<NavigationStates> {
  NavigationCubit() : super(NavigationInit());

  static NavigationCubit get(BuildContext context) => BlocProvider.of(context);

  int currentIndex = 0;

  List<Widget> navigationScreens = [
    const HomeScreen(),
    const MedicineScreen(),
    const ChartsScreen(),
    const VideosScreen()
  ];

  updateCurrentIndex(int index) {
    currentIndex = index;
    emit(NavigationChanged());
  }

  bool speedDialOpened = false;
  updateSpeedDialIOpened(bool opened) {
    speedDialOpened = opened;
    emit(SpeedDialChanged());
  }
}
