abstract class NavigationStates {}

class NavigationInit extends NavigationStates {}

class NavigationChanged extends NavigationStates {}

class SpeedDialChanged extends NavigationStates {}
