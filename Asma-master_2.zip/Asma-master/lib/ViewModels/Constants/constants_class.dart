import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../Models/medicine_model.dart';
import '../../Models/video_model.dart';

class ConstantsClass {
  static String? _uId;

  static setUId(String? uId) {
    _uId = uId;
  }

  static getUId() {
    return _uId;
  }

  static loadUId() {
    _uId = FirebaseAuth.instance.currentUser?.uid;
  }

  static const Color _defaultColor = Color(0xff4EA6CA);

  static Color getDefaultColor() {
    return _defaultColor;
  }

  static const Color _lightDefaultColor = Color(0xffebf8fc);

  static Color getLightDefaultColor() {
    return _lightDefaultColor;
  }

  static const Color _darkDefaultColor = Color(0xff0f8cbf);

  static Color getDarkDefaultColor() {
    return _darkDefaultColor;
  }

  static final List<MedicineModel> _medicines = [
    MedicineModel(
      id: 0,
      name: "ATRODIL 20 μg",
      info: "Inhalation aerosol",
      image: "inhaler.png",
      counterSize: '200',
    ),
    MedicineModel(
      id: 1,
      name: "AB-Flo 100 100 mg",
      info: "tablets",
      image: "drugs.png",
      counterSize: '100',
    ),
    MedicineModel(
      id: 2,
      name: "Advair 250 µg",
      info: "dry powder inhaler",
      image: "inhaler.png",
      counterSize: '250',
    ),
    MedicineModel(
      id: 3,
      name: "Advair 115 µg",
      info: "500 µg dry powder inhaler",
      image: "inhaler.png",
      counterSize: '120',
    ),
    MedicineModel(
      id: 4,
      name: "Riviera Spiromax 50 50 µg +",
      info: "Inhalation aerosol",
      image: "inhaler.png",
      counterSize: '200',
    ),
    MedicineModel(
      id: 5,
      name: "Ahist 5 mg",
      info: "tablets",
      image: "drugs.png",
      counterSize: '30',
    ),
    MedicineModel(
      id: 6,
      name: "Advair 115 µg",
      info: "Inhalation aerosol",
      image: "inhaler.png",
      counterSize: '120',
    ),
  ];

  static List<MedicineModel> getMedicines() {
    return _medicines;
  }

  static final List<VideoModel> _videos = [
    VideoModel(
        title: "Asthma basics",
        description:
            "Learn what asthma is, what effective control of asthma looks like, the difference between controller and reliever medicines and the importance of flu shots.",
        id: "ozyruyITxKg"),
    VideoModel(
        title: "Inhalers with the effective Usage",
        description: "",
        id: "BbONuRXJdr0"),
    VideoModel(
        title: "How to control Asthma", description: "", id: "B-PzxvW2oCM"),
    VideoModel(
        title: "Asthma action plan ", description: "", id: "dvcBapdEFaU"),
    VideoModel(
        title: "Asthma warning signs and what to do",
        description: "",
        id: "k7rLkLYozks"),
  ];

  static List<VideoModel> getVideos() {
    return _videos;
  }
}
