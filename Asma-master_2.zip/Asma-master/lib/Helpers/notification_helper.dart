import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class LocalNotificationHelper {
  static final FlutterLocalNotificationsPlugin
      _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  static Future initialize() async {
    var androidInitialize =
        const AndroidInitializationSettings("mipmap/launcher_icon");
    var initializationSettings =
        InitializationSettings(android: androidInitialize);
    await _flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  static Future showNotification({
    var id,
    required String title,
    required String body,
  }) async {
    AndroidNotificationDetails androidNotificationDetails =
        const AndroidNotificationDetails(
            'high_importance_channel', 'high_importance_channel',
            playSound: false,
            importance: Importance.max,
            priority: Priority.max);

    var notification = NotificationDetails(android: androidNotificationDetails);
    await _flutterLocalNotificationsPlugin.show(id, title, body, notification);
  }
}
