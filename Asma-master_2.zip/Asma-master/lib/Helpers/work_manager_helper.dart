import 'dart:async';

import 'package:asma/Helpers/notification_helper.dart';
import 'package:workmanager/workmanager.dart';

int _reminderCount = 0;
@pragma(
    'vm:entry-point')
void _callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    print(_reminderCount);
    print(_reminderCount);
    LocalNotificationHelper.showNotification(
        id: _reminderCount,
        title: "Reminder",
        body: "It's time to take your medicine");
    return Future.value(true);
  });
}

class WorkManagerHelper {
  static init() async {
    await Workmanager().initialize(_callbackDispatcher, isInDebugMode: false);
  }

  static startTask(List<dynamic> medicineTimes) {
    cancelAllTasks();
    DateTime now = DateTime.now();
    _reminderCount = 0;
    for (var element in medicineTimes) {
      print(element);
      print(now);
      print(_getDateOfCurrentTime(element));
      _reminderCount++;
      print(_getDateOfCurrentTime(element).difference(now));

      Workmanager().registerOneOffTask("task$_reminderCount}", "Reminder",
          initialDelay: _getDateOfCurrentTime(element).difference(now));
    }
  }

  static cancelAllTasks() {
    Workmanager().cancelAll();
  }
}

DateTime _getDateOfCurrentTime(String time) {
  DateTime now = DateTime.now();

  int hours = int.parse(time.split(":").first);
  int minutes = int.parse(time.split(":").last.split(" ").first);
  String am = time.split(" ").last;
  if (hours == 12) {
    hours = 0;
  }
  if (am == "PM") {
    hours += 12;
  }
  DateTime reminderTime =
      DateTime(now.year, now.month, now.day, hours, minutes);
  if (reminderTime.isBefore(now))
    reminderTime = reminderTime.add(Duration(days: 1));
  return reminderTime;
}
