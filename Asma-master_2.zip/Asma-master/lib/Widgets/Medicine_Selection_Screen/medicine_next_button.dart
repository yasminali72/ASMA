import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push.dart';
import 'package:sizer/sizer.dart';
import '../../Views/AddDeviceScreen/add_device_screen.dart';

class MedicineNextButton extends StatelessWidget {
  const MedicineNextButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is PatientMedicineAdded,
      builder: (context, state) => SizedBox(
        width: 100.w,
        child: BuildElevatedButton(
          text: 'Next',
          onPressed: medicineCubit.isMedicineAdded("regular") &&
                  medicineCubit.isMedicineAdded("rescue")
              ? () {
                  buildPush(context, const AddDeviceScreen());
                }
              : null,
          fontSize: 20,
        ),
      ),
    );
  }
}
