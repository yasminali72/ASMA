import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Views/MedicineListScreen/medicine_list_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push.dart';
import 'package:sizer/sizer.dart';

class MedicineSelectionButton extends StatelessWidget {
  final bool main;
  const MedicineSelectionButton({Key? key, required this.main})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is PatientMedicineAdded,
      builder: (context, state) {
        bool medicineAdded = MedicineCubit.get(context)
            .isMedicineAdded(main ? "regular" : "rescue");
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          padding: const EdgeInsets.only(top: 15),
          width: 80.w,
          child: ElevatedButton(
            style: ButtonStyle(
                elevation: MaterialStateProperty.all(0),
                padding: MaterialStateProperty.all(const EdgeInsets.all(10)),
                backgroundColor: MaterialStateProperty.all(
                    ConstantsClass.getLightDefaultColor().withOpacity(.5))),
            onPressed: medicineAdded
                ? null
                : () {
                    buildPush(
                        context,
                        MedicineListScreen(
                          main: main,
                        ));
                  },
            child: medicineAdded
                ? Text(
                    "Medicine Added Successfully",
                    style: TextStyle(color: ConstantsClass.getDefaultColor()),
                  )
                : Icon(
                    Icons.add,
                    color: ConstantsClass.getDarkDefaultColor(),
                  ),
          ),
        );
      },
    );
  }
}
