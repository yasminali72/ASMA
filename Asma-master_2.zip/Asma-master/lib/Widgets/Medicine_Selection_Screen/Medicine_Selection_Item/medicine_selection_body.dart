import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class MedicineSelectionBody extends StatelessWidget {
  final bool main;
  const MedicineSelectionBody({Key? key, required this.main}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return NormalText(
      text:! main
          ? 'Choose your main rescue medication. \nThis field is suitable even if you use \nthe same drug  simultaneously in a regular\ntreatment'
          : 'Choose your regular medication.\nThis filed is suitable for any medicines\nused regularly at fixed times.',
      fontsSize: 14.3,
      color: Colors.black54,
    );
  }
}
