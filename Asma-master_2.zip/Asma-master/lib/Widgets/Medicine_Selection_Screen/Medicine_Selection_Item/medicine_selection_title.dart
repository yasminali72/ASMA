import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class MedicineSelectionTitle extends StatelessWidget {
  final bool main;
  const MedicineSelectionTitle({Key? key, required this.main})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: BoldText(
        text: main ? 'Regular Medications' : 'Main Medications',
        fontsSize: 18.5,
      ),
    );
  }
}
