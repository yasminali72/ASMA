import 'package:asma/Helpers/work_manager_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Views/LayoutScreen/layout_screen.dart';
import 'package:asma/Views/MedicineSelectionScreen/medicine_selection_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push_replacement.dart';
import 'package:asma/Widgets/Shared_Widgets/circular_indicator.dart';
import '../../../ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import '../../../ViewModels/Cubit/SignIn/sign_in_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:asma/Widgets/Shared_Widgets/build_snack_bar.dart';
import 'package:sizer/sizer.dart';

class SignInButton extends StatelessWidget {
  const SignInButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SignInCubit signInCubit = SignInCubit.get(context);
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocConsumer<SignInCubit, SignInStates>(
      buildWhen: (_, current) => current is! PasswordVisibilityChanged,
      listenWhen: (_, current) =>
          current is! PasswordVisibilityChanged || current is! SignInLoading,
      builder: (context, state) => SizedBox(
          width: 100.w,
          child: state is! SignInLoading
              ? BuildElevatedButton(
                  text: "Sign In",
                  onPressed: () {
                    if (signInCubit.formKey.currentState!.validate()) {
                      signInCubit.signIn();
                    }
                  },
                  fontSize: 18.5,
                )
              : const CircularIndicator()),
      listener: (_, state) async {
        if (state is SignInSuccess) {
          await signInCubit.getCurrentPatient().then((value) {
            medicineCubit.getPatientMedicine(signInCubit.patient);
            medicineCubit.getDoses(signInCubit.patient);

            Navigator.pop(context);
            buildPushReplacement(
                context,
                signInCubit.patient!.hasMedicine
                    ? const LayoutScreen()
                    : const MedicineSelectionScreen());
          });
        } else if (state is SignInError) {
          showSnackBar(context, state.error);
        }
      },
    );
  }
}
