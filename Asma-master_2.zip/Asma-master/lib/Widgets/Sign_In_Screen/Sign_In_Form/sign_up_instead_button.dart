import 'package:flutter/material.dart';
import 'package:asma/Views/SgnUpScreen/sign_up_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_text_button.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push_replacement.dart';

class SignUpInsteadButton extends StatelessWidget {
  const SignUpInsteadButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        NormalText(
          text: "Don't have an account?",
          fontsSize: 13,
          color: Colors.red.shade800,
        ),
        BuildTextButton(
            text: "Sign up",
            onPressed: () {
              buildPushReplacement(context, const SignUpScreen());
            })
      ],
    );
  }
}
