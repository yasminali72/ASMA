import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import '../../../ViewModels/Cubit/SignIn/sign_in_states.dart';
import 'package:asma/Widgets/Shared_Widgets/build_text_form_field.dart';

class SignInPasswordTextField extends StatelessWidget {
  const SignInPasswordTextField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SignInCubit signInCubit = SignInCubit.get(context);
    return BlocBuilder<SignInCubit, SignInStates>(
      buildWhen: (_, current) => current is PasswordVisibilityChanged,
      builder: (context, state) => BuildTextFormField(
        validate: (val) {
          if (val == null || val.isEmpty) {
            return "Password is required";
          }
          return null;
        },
        controller: signInCubit.passwordController,
        label: "Password",
        postFix: signInCubit.isPasswordVisible
            ? Icons.visibility_off
            : Icons.visibility,
        showPassword: () {
          signInCubit.changePasswordVisibility();
        },
        obscureText: signInCubit.isPasswordVisible,
      ),
    );
  }
}
