import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/build_text_form_field.dart';

class SignInEmailTextField extends StatelessWidget {
  const SignInEmailTextField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BuildTextFormField(
        validate: (val) {
          if (val == null || val.isEmpty) {
            return "Email is required";
          }
          return null;
        },
        controller: SignInCubit.get(context).emailController,
        label: "Email");
  }
}
