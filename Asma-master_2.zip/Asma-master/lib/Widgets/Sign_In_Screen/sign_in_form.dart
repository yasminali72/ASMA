import 'package:flutter/material.dart';
import 'package:asma/Widgets/Sign_In_Screen/Sign_In_Form/sign_in_button.dart';
import 'package:asma/Widgets/Sign_In_Screen/Sign_In_Form/sign_up_instead_button.dart';
import '../../Widgets/Shared_Widgets/build_sized_box.dart';
import '../../Widgets/Sign_In_Screen/Sign_In_Form/sign_in_password_text_field.dart';
import '../../Widgets/Sign_In_Screen/Sign_In_Form/sign_in_email_text_field.dart';
import '../../ViewModels/Cubit/SignIn/sign_in_cubit.dart';

class SignInForm extends StatelessWidget {
  const SignInForm({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SignInCubit signInCubit = SignInCubit.get(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
      child: SingleChildScrollView(
        child: Form(
          key: signInCubit.formKey,
          child: const Column(
            children: [
              SignInEmailTextField(),
              BuildSizedBox(height: 30),
              SignInPasswordTextField(),
              BuildSizedBox(height: 30),
              SignInButton(),
              BuildSizedBox(height: 10),
              SignUpInsteadButton()
            ],
          ),
        ),
      ),
    );
  }
}
