import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class RemainingText extends StatelessWidget {
  final String counterSize;
  const RemainingText({Key? key, required this.counterSize}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is RemainingMedicineUpdated,
      builder: (_, __) => BoldText(
          text:
              "${MedicineCubit.get(context).remainingMedicine.toInt()}/$counterSize",
          fontsSize: 22.5,
          color: ConstantsClass.getDefaultColor()),
    );
  }
}
