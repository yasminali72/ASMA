import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:sizer/sizer.dart';

class RemainingSlider extends StatelessWidget {
  final String counterSize;
  const RemainingSlider({Key? key, required this.counterSize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is RemainingMedicineUpdated,
      builder: (context, state) => SizedBox(
        width: 100.w,
        child: CupertinoSlider(
          min: 0,
          max: double.parse(counterSize),
          value: medicineCubit.remainingMedicine,
          onChanged: (val) {
            medicineCubit.updateRemainingMedicine(val);
          },
          activeColor: ConstantsClass.getDefaultColor(),
        ),
      ),
    );
  }
}
