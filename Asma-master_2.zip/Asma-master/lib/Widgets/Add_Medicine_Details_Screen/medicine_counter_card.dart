import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';
import '../../ViewModels/Constants/constants_class.dart';

class MedicineCounterCard extends StatelessWidget {
  final String counterSize;
  const MedicineCounterCard({Key? key, required this.counterSize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.w,
      height: 115,
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              BoldText(
                text: "Counter size:",
                fontsSize: 14.5,
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: ConstantsClass.getDefaultColor(),
                ),
                padding: const EdgeInsets.all(12),
                child: BoldText(
                  text: counterSize,
                  fontsSize: 16.5,
                  color: Colors.white,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
