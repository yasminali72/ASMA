import 'package:flutter/material.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/Medicine_Planned_Usages/add_planned_usages.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/Medicine_Planned_Usages/added_planned_usages.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class MedicinePlannedUsages extends StatelessWidget {
  final String type;
  const MedicinePlannedUsages(
      {Key? key, required this.type})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.w,
      child: Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BoldText(text: "Set planned usages:", fontsSize: 14.5),
              const BuildSizedBox(height: 20),
              AddedPlannedUsages(type: type),
              const BuildSizedBox(height: 15),
              AddPlannedUsages(type: type)
            ],
          ),
        ),
      ),
    );
  }
}
