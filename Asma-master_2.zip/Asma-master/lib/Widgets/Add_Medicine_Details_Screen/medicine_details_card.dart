import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class MedicineDetailsCard extends StatelessWidget {
  final MedicineModel medicineModel;
  const MedicineDetailsCard({Key? key, required this.medicineModel})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.w,
      height: 150,
      child: Card(
        elevation: 0,
        child: Column(
          children: [
            const BuildSizedBox(
              height: 20,
            ),
            Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(3.0),
                  child: Image(
              image: AssetImage("assets/images/${medicineModel.image}"),
              fit: BoxFit.fill,
            ),
                )),
            const BuildSizedBox(
              height: 5,
            ),
            BoldText(text: medicineModel.name, fontsSize: 15.5),
            NormalText(
              text: medicineModel.info,
              fontsSize: 11.5,
              color: Colors.grey,
            ),
            const BuildSizedBox(
              height: 5,
            ),
          ],
        ),
      ),
    );
  }
}
