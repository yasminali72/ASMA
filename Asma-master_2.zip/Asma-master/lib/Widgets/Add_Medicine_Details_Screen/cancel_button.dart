import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:sizer/sizer.dart';

class CancelButton extends StatelessWidget {
  const CancelButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      width: 100.w,
      child: BuildElevatedButton(
        empty: true,
        text: "Cancel",
        onPressed: () {
          Navigator.pop(context);
        },
        fontSize: 16,
      ),
    );
  }
}
