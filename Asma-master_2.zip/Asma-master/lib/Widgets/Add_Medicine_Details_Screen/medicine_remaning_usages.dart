import 'package:flutter/material.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/Medicine_Remaining_Usages/remaining_slider.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/Medicine_Remaining_Usages/remaining_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class MedicineRemainingUsage extends StatelessWidget {
  final String counterSize;
  const MedicineRemainingUsage({Key? key, required this.counterSize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BoldText(
              text: 'Set remaining usages: ',
              fontsSize: 14.5,
            ),
            const BuildSizedBox(height: 10),
            RemainingText(counterSize: counterSize),
            const BuildSizedBox(height: 10),
            RemainingSlider(counterSize: counterSize)
          ],
        ),
      ),
    );
  }
}
