import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Views/MedicineDosesScreen/medicine_doses_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push.dart';
import 'package:sizer/sizer.dart';

class AddPlannedUsages extends StatelessWidget {
  final String type;
  const AddPlannedUsages({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.w,
      child: ElevatedButton(
          style: ButtonStyle(
              shape: MaterialStateProperty.all(RoundedRectangleBorder(
                  side: BorderSide(
                      color: ConstantsClass.getDefaultColor(), width: 1.5))),
              elevation: MaterialStateProperty.all(0),
              backgroundColor: MaterialStateProperty.all(Colors.white)),
          onPressed: () {
            buildPush(context, MedicineDosesScreen(type: type));
          },
          child: BlocBuilder<MedicineCubit, MedicineStates>(
            buildWhen: (_, current) => current is ReminderAdded,
            builder: (_, __) => BoldText(
              text: MedicineCubit.get(context).isPlannedAdded(type)
                  ? "Change"
                  : "Add planned usages",
              color: ConstantsClass.getDefaultColor(),
              fontsSize: 13.3,
            ),
          )),
    );
  }
}
