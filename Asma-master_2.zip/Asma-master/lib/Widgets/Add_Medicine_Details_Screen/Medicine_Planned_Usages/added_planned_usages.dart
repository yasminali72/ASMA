import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class AddedPlannedUsages extends StatelessWidget {
  final String type;
  const AddedPlannedUsages({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is ReminderAdded,
      builder: (context, state) => Container(
        width: 100.w,
        padding: const EdgeInsets.all(12),
        color: Colors.grey.shade100,
        alignment: Alignment.center,
        child: BoldText(
          color: !medicineCubit.isPlannedAdded(type)
              ? Colors.red.shade300
              : Colors.green.shade300,
          text: !medicineCubit.isPlannedAdded(type)
              ? 'No planned usages added yet'
              : 'Planned usages added successfully',
          fontsSize: 13.3,
        ),
      ),
    );
  }
}
