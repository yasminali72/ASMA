import 'package:flutter/material.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/condition_confirm_text.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/password_text_field.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/sign_in_instead_button.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/sign_up_button.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/sign_up_name_text_field.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/sign_up_email_controller.dart';
import '../../Widgets/Sign_Up_Screen/Sign_Up_Form/sign_up_phone_controller.dart';
import '../../ViewModels/Cubit/SignUp/sign_up_cubit.dart';
import '../../Widgets/Shared_Widgets/build_sized_box.dart';

class SignUpForm extends StatelessWidget {
  const SignUpForm({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SignUpCubit signUpCubit = SignUpCubit.get(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
      child: SingleChildScrollView(
        child: Form(
          key: signUpCubit.formKey,
          child: const Column(
            children: [
              BuildSizedBox(height: 10),
              SignUpNameTextField(),
              BuildSizedBox(height: 30),
              SignUpEmailController(),
              BuildSizedBox(height: 30),
              SignUpPhoneController(),
              BuildSizedBox(height: 30),
              SignUpPasswordTextField(),
              BuildSizedBox(height: 10),
              ConditionConfirmText(),
              BuildSizedBox(height: 30),
              SignUpButton(),
              SignInInsteadButton(),
              BuildSizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
