import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/Views/MedicineSelectionScreen/medicine_selection_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push_replacement.dart';
import '../../../ViewModels/Cubit/SignUp/sign_up_cubit.dart';
import '../../../ViewModels/Cubit/SignUp/sign_up_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:asma/Widgets/Shared_Widgets/build_snack_bar.dart';
import '../../../Widgets/Shared_Widgets/circular_indicator.dart';
import 'package:sizer/sizer.dart';

class SignUpButton extends StatelessWidget {
  const SignUpButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SignUpCubit signUpCubit = SignUpCubit.get(context);
    return BlocConsumer<SignUpCubit, SignUpStates>(
      buildWhen: (_, current) => current is! PasswordVisibilityChanged,
      listenWhen: (_, current) =>
          current is! PasswordVisibilityChanged || current is! SignUpLoading,
      builder: (context, state) => SizedBox(
        width: 100.w,
        child: state is SignUpLoading
            ? const CircularIndicator()
            : BuildElevatedButton(
                text: "Sign Up",
                onPressed: () {
                  if (signUpCubit.formKey.currentState!.validate()) {
                    signUpCubit.signUp();
                  }
                },
                fontSize: 18.5,
              ),
      ),
      listener: (_, state) {
        if (state is SignUpSuccess) {
          SignInCubit.get(context).patient = signUpCubit.patient!;
          buildPushReplacement(context, const MedicineSelectionScreen());
        } else if (state is SignUpError) {
          showSnackBar(context, state.error);
        }
      },
    );
  }
}