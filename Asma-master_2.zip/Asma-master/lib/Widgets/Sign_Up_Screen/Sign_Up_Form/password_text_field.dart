import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../ViewModels/Cubit/SignUp/sign_up_cubit.dart';
import '../../../ViewModels/Cubit/SignUp/sign_up_states.dart';
import 'package:asma/Widgets/Shared_Widgets/build_text_form_field.dart';

class SignUpPasswordTextField extends StatelessWidget {
  const SignUpPasswordTextField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SignUpCubit signUpCubit = SignUpCubit.get(context);
    return BlocBuilder<SignUpCubit, SignUpStates>(
      buildWhen: (_, current) => current is PasswordVisibilityChanged,
      builder: (context, state) => BuildTextFormField(
        validate: (val) {
          if (val == null || val.isEmpty) {
            return "Password is required";
          }
          return null;
        },
        controller: signUpCubit.passwordController,
        label: "Password",
        postFix: signUpCubit.isPasswordVisible
            ? Icons.visibility_off
            : Icons.visibility,
        showPassword: () {
          signUpCubit.changePasswordVisibility();
        },
        obscureText: signUpCubit.isPasswordVisible,
      ),
    );
  }
}
