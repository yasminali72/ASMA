import 'package:flutter/material.dart';
import '../../../Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/underline_text.dart';
import '../../../Widgets/Shared_Widgets/Texts/normal_text.dart';

class ConditionConfirmText extends StatelessWidget {
  const ConditionConfirmText({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Wrap(
      children: [
        NormalText(
          text: 'By clicking ',
          fontsSize: 12,
        ),
        BoldText(
          text: 'Sign Up',
          fontsSize: 11,
        ),
        NormalText(
          text: ', you agree to our ',
          fontsSize: 12,
        ),
        UnderlineText(text: 'Terms of User ', fontsSize: 11),
        NormalText(
          text: 'and our ',
          fontsSize: 12,
        ),
        UnderlineText(text: 'Privacy Policy ', fontsSize: 11),
      ],
    );
  }
}
