import 'package:flutter/material.dart';
import 'package:asma/Views/SignInScreen/sign_in_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_text_button.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push.dart';

class SignInInsteadButton extends StatelessWidget {
  const SignInInsteadButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        NormalText(
          text: "Already have an account?",
          fontsSize: 13,
          color: Colors.red.shade800,
        ),
        BuildTextButton(
            text: "Sign in",
            onPressed: () {
              buildPush(context, const SignInScreen());
            })
      ],
    );
  }
}
