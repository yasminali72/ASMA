import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/SignUp/sign_up_cubit.dart';
import '../../../Widgets/Shared_Widgets/build_text_form_field.dart';

class SignUpNameTextField extends StatelessWidget {
  const SignUpNameTextField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BuildTextFormField(
        validate: (val) {
          if (val == null || val.isEmpty) {
            return "Name is required";
          }
          return null;
        },
        controller: SignUpCubit.get(context).nameController,
        label: "Name");
  }
}
