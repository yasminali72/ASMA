import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/SignUp/sign_up_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/build_text_form_field.dart';

class SignUpPhoneController extends StatelessWidget {
  const SignUpPhoneController({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BuildTextFormField(
        validate: (val) {
          if (val == null || val.isEmpty) {
            return "Phone is required";
          }
          return null;
        },
        keyboard: TextInputType.number,
        controller: SignUpCubit.get(context).phoneController,
        label: "Phone");
  }
}
