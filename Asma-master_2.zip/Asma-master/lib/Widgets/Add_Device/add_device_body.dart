import 'package:flutter/material.dart';
import 'package:asma/Widgets/Add_Device/Add_Device_Body/add_device_question.dart';
import 'package:asma/Widgets/Add_Device/Add_Device_Body/device_skip_button.dart';
import 'package:asma/Widgets/Add_Device/Add_Device_Body/loading_container.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';
import 'Add_Device_Body/device_data.dart';
import 'Add_Device_Body/add_device_button.dart';

class AddDeviceBody extends StatelessWidget {
  const AddDeviceBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: SingleChildScrollView(
            child: SizedBox(
              width: 100.w,
              child: const Column(
                children: [
                  AddDeviceQuestion(),
                  BuildSizedBox(height: 20),
                  DeviceData(),
                  AddDeviceButton(),
                  BuildSizedBox(height: 30),
                  DeviceSkipButton(),
                  //NoDevice()
                ],
              ),
            ),
          ),
        ),
        const LoadingContainer()
      ],
    );
  }
}
