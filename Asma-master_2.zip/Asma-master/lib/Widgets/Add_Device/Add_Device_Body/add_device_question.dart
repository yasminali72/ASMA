import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class AddDeviceQuestion extends StatelessWidget {
  const AddDeviceQuestion({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BoldText(
          text: "Do you have a device?",
          fontsSize: 19.5,
        ),
        const BuildSizedBox(
          height: 5,
        ),
        BoldText(
          text:
              "If you have one or more  of Asma devices, \nyou can connect it now",
          fontsSize: 14.3,
          color: Colors.grey,
        )
      ],
    );
  }
}
