import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

import '../../Shared_Widgets/Buttons/build_elevated_button.dart';

class NoDevice extends StatelessWidget {
  const NoDevice({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 70.w,
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(7),
            side: BorderSide(width: 2, color: Colors.grey.withOpacity(.1))),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              BoldText(text: "I don't have a device", fontsSize: 14.sp),
              const BuildSizedBox(height: 15),
              BoldText(
                text: "Track usages manually, Asma \ndevice may be added later",
                fontsSize: 11.sp,
                color: Colors.grey,
              ),
              const BuildSizedBox(height: 15),
              BuildElevatedButton(
                text: "Use without device",
                onPressed: () {
                  MedicineCubit.get(context).connectDeviceAndAddMedicine(
                      false, SignInCubit.get(context).patient!);
                },
                fontSize: 13.sp,
                empty: true,
              )
            ],
          ),
        ),
      ),
    );
  }
}
