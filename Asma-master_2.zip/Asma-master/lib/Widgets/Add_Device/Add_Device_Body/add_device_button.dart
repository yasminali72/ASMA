import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:sizer/sizer.dart';

class AddDeviceButton extends StatelessWidget {
  const AddDeviceButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 70.w,
      child: BuildElevatedButton(
          text: "Connect",
          onPressed: () {
            MedicineCubit.get(context).connectDeviceAndAddMedicine(
                true, SignInCubit.get(context).patient!);
          },
          fontSize: 16.5),
    );
  }
}
