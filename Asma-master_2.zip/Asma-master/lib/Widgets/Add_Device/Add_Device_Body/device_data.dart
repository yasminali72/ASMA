import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/build_text_form_field.dart';
import 'package:sizer/sizer.dart';

class DeviceData extends StatelessWidget {
  const DeviceData({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
            height: 25.h,
            child: const Image(image: AssetImage("assets/images/logo.png"))),
        SizedBox(
          width: 70.w,
          child: BuildTextFormField(
              controller: MedicineCubit.get(context).deviceController,
              label: "Serial number"),
        )
      ],
    );
  }
}
