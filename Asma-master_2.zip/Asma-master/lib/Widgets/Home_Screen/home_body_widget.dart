import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'Home_Body_Widget/control_body_widget.dart';
import 'Home_Body_Widget/measure_body_widget.dart';

class HomeBodyWidget extends StatelessWidget {
  const HomeBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is UpdateHomeTopButtonIndex,
      builder: (context, state) => Container(
        child: MedicineCubit.get(context).homeTopButtonIndex == 0
            ? const ControlBodyWidget()
            : const MeasureBodyWidget(),
      ),
    );
  }
}
