import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Home_Screen/Home_Top_Buttons/home_button_container.dart';
import 'package:asma/Widgets/Shared_Widgets/log_out_button.dart';

class HomeTopButtons extends StatelessWidget {
  const HomeTopButtons({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 12),
            height: 35,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: ConstantsClass.getDefaultColor()),
              borderRadius: BorderRadius.circular(40),
            ),
            child: const Row(
              children: [
                HomeButtonContainer(currentIndex: 0),
                HomeButtonContainer(currentIndex: 1),
              ],
            ),
          ),
        ),
        const LogOutButton()
      ],
    );
  }
}
