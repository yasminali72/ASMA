import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class HomeButtonContainer extends StatelessWidget {
  final int currentIndex;
  const HomeButtonContainer({Key? key, required this.currentIndex})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is UpdateHomeTopButtonIndex,
      builder: (context, state) => Expanded(
          child: InkWell(
        child: Container(
          alignment: Alignment.center,
          height: 35,
          decoration: BoxDecoration(
            color: medicineCubit.homeTopButtonIndex == currentIndex
                ? ConstantsClass.getDefaultColor()
                : Colors.white,
            borderRadius: BorderRadius.circular(40),
          ),
          child: BoldText(
            text: currentIndex == 0 ? "Control" : "Measures",
            fontsSize: 16,
            color: medicineCubit.homeTopButtonIndex == currentIndex
                ? Colors.white
                : Colors.black,
          ),
        ),
        onTap: () {
          medicineCubit.updateHomeTopButtonIndex(currentIndex);
        },
      )),
    );
  }
}
