import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:asma/ViewModels/Cubit/Sensors/sensors_states.dart';
import 'package:asma/Widgets/Shared_Widgets/circular_indicator.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/location_widget.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/pm_air_data.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../ViewModels/Constants/constants_class.dart';
import 'Measure_Body_Widget/pm_temperature_data.dart';
import 'Measure_Body_Widget/humanity_dust_data.dart';
import 'Measure_Body_Widget/heart_spo_data.dart';

class MeasureBodyWidget extends StatelessWidget {
  const MeasureBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: ConstantsClass.getDefaultColor(),
      onRefresh: () async {
         SensorsCubit.get(context).loadSensorsData();
      },
      child: BlocBuilder<SensorsCubit, SensorsStates>(
        builder: (context, state) => state is SensorsDataLoading
            ? CircularIndicator()
            : Padding(
                padding: EdgeInsets.symmetric(horizontal: 15.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      LocationWidget(),
                      BuildSizedBox(height: 10),
                      PmTemperature(),
                      BuildSizedBox(height: 10),
                      PmAirData(),
                      BuildSizedBox(height: 10),
                      HumanityDustData(),
                      BuildSizedBox(height: 10),
                      HeartSpoData(),
                      BuildSizedBox(height: 10),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
