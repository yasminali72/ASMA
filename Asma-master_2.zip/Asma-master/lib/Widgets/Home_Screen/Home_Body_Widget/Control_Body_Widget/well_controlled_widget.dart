import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';
import 'Well_Controlled_Widget/figure_data_widget.dart';

class WellControlledWidget extends StatelessWidget {
  const WellControlledWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: (100.w - 224 - 16) / 14),
      child: Card(
        shape: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey.withOpacity(.4))),
        color: ConstantsClass.getDefaultColor(),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BoldText(
                text: "Well-Controlled",
                fontsSize: 19.5,
                color: Colors.white.withOpacity(.9),
              ),
              BoldText(
                text: "Based on 7 previous days",
                fontsSize: 11,
                color: Colors.white.withOpacity(.6),
              ),
              const BuildSizedBox(
                height: 10,
              ),
              const FigureDataWidget(),
              const BuildSizedBox(
                height: 5,
              )
            ],
          ),
        ),
      ),
    );
  }
}
