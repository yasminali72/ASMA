import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class UsageRow extends StatelessWidget {
  final String image;
  final String count;
  final String text;
  const UsageRow(
      {Key? key, required this.image, required this.count, required this.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7.0),
      child: Row(
        children: [
          SizedBox(
              height: 20,
              width: 20,
              child: Image(image: AssetImage("assets/images/$image.png"))),
          const BuildSizedBox(
            width: 3,
          ),
          BoldText(
            text: "$text usages",
            fontsSize: 13.5,
            color: Colors.white.withOpacity(.9),
          ),
          const Spacer(),
          BoldText(
            text: count,
            fontsSize: 13.5,
            color: Colors.white.withOpacity(.9),
          )
        ],
      ),
    );
  }
}
