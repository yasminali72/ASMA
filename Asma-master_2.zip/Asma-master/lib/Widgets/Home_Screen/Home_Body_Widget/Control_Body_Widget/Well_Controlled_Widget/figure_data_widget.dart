import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/Well_Controlled_Widget/usage_row.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class FigureDataWidget extends StatelessWidget {
  const FigureDataWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print(MedicineCubit.get(context).getNightUsages());
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return Row(
      children: [
        BlocBuilder<MedicineCubit, MedicineStates>(
          buildWhen: (_, current) =>
              current is GetRegularDoses || current is GetRescueDoses,
          builder: (context, state) => Expanded(
              child: Column(
            children: [
              UsageRow(
                  image: "night",
                  count: medicineCubit.getNightUsages(),
                  text: "Night"),
              UsageRow(
                  image: "day",
                  count: medicineCubit.getDayUsages(),
                  text: "Day"),
            ],
          )),
        ),
        BuildSizedBox(
          width: 10,
        ),
        Expanded(
            child: Padding(
          padding: EdgeInsets.only(left: 10.0),
          child: Image(image: AssetImage("assets/images/figure.png")),
        ))
      ],
    );
  }
}
