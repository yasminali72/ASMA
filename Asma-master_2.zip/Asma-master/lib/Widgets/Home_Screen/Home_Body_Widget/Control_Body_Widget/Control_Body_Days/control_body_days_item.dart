import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class ControlBodyDaysItem extends StatelessWidget {
  final int index;
  const ControlBodyDaysItem({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return Container(
      margin: EdgeInsets.symmetric(horizontal: (100.w - 224 - 16) / 14),
      width: 32,
      decoration: BoxDecoration(
          color: medicineCubit.dayButtonIndex == index
              ? ConstantsClass.getDefaultColor()
              : Colors.white,
          border: Border.all(color: Colors.grey.withOpacity(.5)),
          borderRadius: BorderRadius.circular(6)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          BoldText(
            text: medicineCubit.days[index],
            fontsSize: 16,
            color: medicineCubit.dayButtonIndex == index
                ? Colors.white
                : Colors.black,
          ),
          NormalText(
            text: (index + 1).toString(),
            fontsSize: 14,
            color: medicineCubit.dayButtonIndex == index
                ? Colors.white
                : Colors.grey,
          )
        ],
      ),
    );
  }
}
