import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/Usages_Details_Widget/usages_details_body.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/Usages_Details_Widget/usages_details_title.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class UsagesDetailsWidget extends StatelessWidget {
  const UsagesDetailsWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: (100.w - 224 - 16) / 14),
      child: const Column(
        children: [
          UsagesDetailsTitle(
            title: "Rescue Usages",
            subTitle: "Usages",
          ),
          BuildSizedBox(height: 10),
          UsagesDetailsBody(regular: false),
          BuildSizedBox(height: 30),
          UsagesDetailsTitle(
            title: "Planned Usages",
            subTitle: "Taken",
          ),
          BuildSizedBox(height: 10),
          UsagesDetailsBody(regular: true),
        ],
      ),
    );
  }
}
