import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/Control_Body_Days/control_body_days_item.dart';
import 'package:sizer/sizer.dart';

class ControlBodyDays extends StatelessWidget {
  const ControlBodyDays({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is UpdateDayButtonIndex,
      builder: (context, state) => SizedBox(
        height: 55,
        width: 100.w,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: 7,
          itemBuilder: (_, index) => InkWell(
            onTap: () {
              medicineCubit.updateDayButtonIndex(index);
            },
            child: ControlBodyDaysItem(
              index: index,
            ),
          ),
        ),
      ),
    );
  }
}
