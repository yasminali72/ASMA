import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class DosesTimesText extends StatelessWidget {
  final bool regular;
  const DosesTimesText({super.key, required this.regular});

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);

    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) =>
          current is IncreaseDosesSuccess ||
          current is GetRegularDoses ||
          current is GetRescueDoses ||
          current is UpdateDayButtonIndex,
      builder: (context, state) => NormalText(
        text: regular
            ? medicineCubit.getRegularUsageTime()
            : medicineCubit.getRecueUsageTime(),
        fontsSize: 12.2,
        color: Colors.grey.shade500,
      ),
    );
  }
}
