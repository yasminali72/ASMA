import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/Usages_Details_Widget/Usages_Details_Title/doses_circle_avatar.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class UsagesDetailsTitle extends StatelessWidget {
  final String title;
  final String subTitle;
  const UsagesDetailsTitle(
      {Key? key, required this.title, required this.subTitle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        BoldText(
          text: title,
          fontsSize: 17,
        ),
        const Spacer(),
        BoldText(
          text: subTitle,
          fontsSize: 16,
          color: Colors.grey.shade400,
        ),
        const BuildSizedBox(
          width: 10,
        ),
        DosesCircleAvatar(
          subTitle: subTitle,
        )
      ],
    );
  }
}
