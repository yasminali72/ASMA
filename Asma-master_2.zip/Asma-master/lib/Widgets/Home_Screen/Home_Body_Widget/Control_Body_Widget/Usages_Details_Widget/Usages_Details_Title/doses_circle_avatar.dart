import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';

class DosesCircleAvatar extends StatelessWidget {
  final String subTitle;
  const DosesCircleAvatar({super.key, required this.subTitle});

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);

    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) =>
          current is UpdateDayButtonIndex || current is IncreaseDosesSuccess,
      builder: (context, state) {
        int doneRegularDoses = medicineCubit.getRegularDosesLocal().length;
        int requiredRegularDoses = medicineCubit
            .regularPatientMedicine!.reminderModel!.medicineTimes.length;

        int rescueDoses = medicineCubit.getRescueDosesLocal().length;
        return CircleAvatar(
          radius: 17,
          backgroundColor: ConstantsClass.getDefaultColor(),
          child: BoldText(
            text: subTitle == "Usages"
                ? rescueDoses.toString()
                : "$doneRegularDoses/$requiredRegularDoses",
            color: Colors.white,
            fontsSize: 14,
          ),
        );
      },
    );
  }
}
