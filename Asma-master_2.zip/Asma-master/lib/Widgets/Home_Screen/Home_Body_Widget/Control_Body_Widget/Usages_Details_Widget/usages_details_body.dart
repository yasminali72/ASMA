import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/Usages_Details_Widget/Usages_Details_Body/doses_times_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class UsagesDetailsBody extends StatelessWidget {
  final bool regular;
  const UsagesDetailsBody({Key? key, required this.regular}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    MedicineModel regularModel = medicineCubit.getRegularMedicine();
    MedicineModel rescueModel = medicineCubit.getRescueMedicine();

    return Card(
      shape: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey.withOpacity(.1)),
          borderRadius: BorderRadius.circular(8)),
      child: ListTile(
        leading: SizedBox(
            height: 35,
            child: Image(
                image: AssetImage(
                    "assets/images/${regular ? regularModel.image : rescueModel.image}"))),
        trailing: RotatedBox(
            quarterTurns: 135,
            child: Icon(
              Icons.arrow_drop_down_circle_outlined,
              color: ConstantsClass.getDefaultColor(),
            )),
        title: BoldText(
            text: regular ? regularModel.name : rescueModel.name,
            fontsSize: 16),
        subtitle: DosesTimesText(
          regular: regular,
        ),
      ),
    );
  }
}
