import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:intl/intl.dart';
import 'package:sizer/sizer.dart';

class ControlDayDate extends StatelessWidget {
  const ControlDayDate({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is UpdateDayButtonIndex,
      builder: (context, state) => Padding(
        padding: EdgeInsets.symmetric(horizontal: (100.w - 224 - 16) / 14),
        child: Row(
          children: [
            Icon(
              Icons.date_range_outlined,
              color: ConstantsClass.getDefaultColor(),
              size: 20,
            ),
            const BuildSizedBox(width: 5),
            BoldText(
              text: DateFormat('d MMMM y, EEEE')
                  .format(medicineCubit.getDayOfCurrentIndex()),
              fontsSize: 17,
              color: ConstantsClass.getDefaultColor(),
            )
          ],
        ),
      ),
    );
  }
}
