import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class JournalText extends StatelessWidget {
  const JournalText({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: (100.w - 224 - 16) / 14),
      child: NormalText(
        text: "Journal",
        fontsSize: 28,
      ),
    );
  }
}
