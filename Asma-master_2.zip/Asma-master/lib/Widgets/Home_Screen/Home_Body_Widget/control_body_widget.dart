import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/control_day_date.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/usages_details_widget.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Control_Body_Widget/well_controlled_widget.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'Control_Body_Widget/control_body_days.dart';
import 'Control_Body_Widget/journal_text.dart';

class ControlBodyWidget extends StatelessWidget {
  const ControlBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(8.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BuildSizedBox(height: 10),
            ControlBodyDays(),
            BuildSizedBox(height: 30),
            JournalText(),
            BuildSizedBox(height: 7),
            ControlDayDate(),
            BuildSizedBox(height: 16),
            WellControlledWidget(),
            BuildSizedBox(height: 16),
            UsagesDetailsWidget()
          ],
        ),
      ),
    );
  }
}
