import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:sizer/sizer.dart';

class MeasureCircularItem extends StatelessWidget {
  final String title;
  final String subTitle;
  final String value;
  const MeasureCircularItem(
      {Key? key,
      required this.title,
      required this.subTitle,
      required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 150,
      width: 130,
      child: Card(
        shape: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: BorderSide(color: Colors.grey.withOpacity(.1))),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              BoldText(
                text: title,
                fontsSize: 12.sp,
                color: ConstantsClass.getDefaultColor(),
              ),
              Expanded(
                  child: CircularPercentIndicator(
                backgroundColor: ConstantsClass.getLightDefaultColor(),
                radius: 27,
                percent: .3,
                progressColor: ConstantsClass.getDarkDefaultColor(),
                center: BoldText(text: value, fontsSize: 17),
              )),
              BoldText(
                text: subTitle,
                fontsSize: 12.sp,
                color: Colors.grey.shade400,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
