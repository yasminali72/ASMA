import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class MeasureSimpleItem extends StatelessWidget {
  final String title;
  final String value;
  final String measure;
  final bool? percent;
  final bool? smallMeasure;
  const MeasureSimpleItem(
      {Key? key,
      required this.title,
      required this.value,
      required this.measure,
      this.percent,
      this.smallMeasure})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50.w,
      width: 40.w,
      child: Card(
        shape: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: BorderSide(color: Colors.grey.withOpacity(.1))),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Expanded(
                child: BoldText(
                  text: title,
                  fontsSize: 14.5,
                  color: ConstantsClass.getDefaultColor(),
                ),
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    BoldText(
                      text: value,
                      fontsSize: 22,
                    ),
                    if (percent != null)
                      const BuildSizedBox(
                        width: 10,
                      ),
                    BoldText(
                      text: measure,
                      fontsSize: smallMeasure != null ? 12 : 22,
                      color: Colors.grey.shade500,
                    )
                  ],
                ),
              ),
              const Spacer()
            ],
          ),
        ),
      ),
    );
  }
}
