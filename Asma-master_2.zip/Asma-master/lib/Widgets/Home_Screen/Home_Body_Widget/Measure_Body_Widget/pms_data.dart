import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/Measure_Items/measure_circular_item.dart';
import 'package:sizer/sizer.dart';

class PMsData extends StatelessWidget {
  const PMsData({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SensorsCubit sensorsCubit = SensorsCubit.get(context);
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: (100.w - 290) / 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
         // ,
        ],
      ),
    );
  }
}
