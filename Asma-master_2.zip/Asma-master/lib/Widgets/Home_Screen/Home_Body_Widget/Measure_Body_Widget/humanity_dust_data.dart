import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/Measure_Items/measure_circular_item.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/Measure_Items/measure_simple_item.dart';
import 'package:sizer/sizer.dart';

class HumanityDustData extends StatelessWidget {
  const HumanityDustData({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SensorsCubit sensorsCubit = SensorsCubit.get(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        MeasureSimpleItem(
            title: "Humidity",
            value: sensorsCubit.sensorsModel.humidity.toString(),
            measure: "%"),
        MeasureSimpleItem(
            title: "Dust Density",
            value: sensorsCubit.sensorsModel.dustDensity.toString(), measure: 'μg/m',
        smallMeasure: true,)
      ],
    );
  }
}
