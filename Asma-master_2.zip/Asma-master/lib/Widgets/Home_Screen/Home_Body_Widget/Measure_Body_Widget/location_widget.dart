import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class LocationWidget extends StatelessWidget {
  const LocationWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5),
          side: BorderSide(color: Colors.grey.withOpacity(.2), width: 1.5)),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          children: [
            Icon(
              Icons.place,
              color: ConstantsClass.getDefaultColor(),
              size: 20,
            ),
            const BuildSizedBox(
              width: 5,
            ),
            BoldText(
              text: "Mansoura",
              fontsSize: 16,
              color: ConstantsClass.getDefaultColor(),
            )
          ],
        ),
      ),
    );
  }
}
