import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/Measure_Items/measure_simple_item.dart';
import 'package:sizer/sizer.dart';

import '../../../../ViewModels/Cubit/Sensors/sensors_cubit.dart';

class HeartSpoData extends StatelessWidget {
  const HeartSpoData({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SensorsCubit sensorsCubit = SensorsCubit.get(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        MeasureSimpleItem(
          smallMeasure: true,
          title: "Heart rate",
          value: sensorsCubit.sensorsModel.heartRate.toString(),
          measure: "bpm",
        ),
        MeasureSimpleItem(
          title: "Sp02",
          value: sensorsCubit.sensorsModel.sp02.toString(),
          measure: "%",
        ),
      ],
    );
  }
}
