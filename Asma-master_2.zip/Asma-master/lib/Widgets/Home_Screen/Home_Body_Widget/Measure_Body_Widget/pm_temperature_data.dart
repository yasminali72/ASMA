import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/Home_Body_Widget/Measure_Body_Widget/Measure_Items/measure_simple_item.dart';
import 'package:sizer/sizer.dart';

import 'Measure_Items/measure_circular_item.dart';

class PmTemperature extends StatelessWidget {
  const PmTemperature({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SensorsCubit sensorsCubit = SensorsCubit.get(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        MeasureSimpleItem(
          title: "PM 10",
          value: sensorsCubit.sensorsModel.pm10.toString(),
          measure: 'ug/m3',
          smallMeasure: true,
        ),
        MeasureSimpleItem(
            title: "Temperature",
            value: sensorsCubit.sensorsModel.temperature.toString(),
            measure: "\u{0366}c",
            percent: true),
      ],
    );
  }
}
