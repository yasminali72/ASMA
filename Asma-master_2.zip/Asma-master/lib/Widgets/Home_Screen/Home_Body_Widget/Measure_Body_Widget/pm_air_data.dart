import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

import 'Measure_Items/measure_simple_item.dart';

class PmAirData extends StatelessWidget {
  const PmAirData({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SensorsCubit sensorsCubit = SensorsCubit.get(context);

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        MeasureSimpleItem(
          title: "PM 2.5",
          value: sensorsCubit.sensorsModel.pm25.toString(),
          measure: 'ug/m3',
          smallMeasure: true,
        ),
        MeasureSimpleItem(
            title: "Air Quality",
            value: sensorsCubit.sensorsModel.gasConcentration.toString(),
            measure: ""),
      ],
    );
  }
}
