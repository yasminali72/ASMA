import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';

class MedicineSearchTextField extends StatelessWidget {
  const MedicineSearchTextField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return TextField(
      decoration: const InputDecoration(
          border: InputBorder.none,
          isCollapsed: true,
          hintText: "medicine name"),
      controller: medicineCubit.searchController,
      onChanged: (_) {
        medicineCubit.searchMedicine();
      },
    );
  }
}
