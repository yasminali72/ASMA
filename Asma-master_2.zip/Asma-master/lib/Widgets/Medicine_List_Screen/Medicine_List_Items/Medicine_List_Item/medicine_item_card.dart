import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class MedicineItemCard extends StatelessWidget {
  final int index;
  const MedicineItemCard({Key? key, required this.index}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<MedicineModel> medicines = MedicineCubit.get(context).getMedicine();

    return Card(
      elevation: 0,
      child: ListTile(
        leading: Image(
          image: AssetImage("assets/images/${medicines[index].image}"),
          height: 30,
        ),
        title: BoldText(text: medicines[index].name, fontsSize: 16.2),
        subtitle: NormalText(
          text: medicines[index].info,
          fontsSize: 13.4,
          color: Colors.grey,
        ),
        trailing: RotatedBox(
          quarterTurns: 135,
          child: Icon(
            Icons.arrow_drop_down_circle_outlined,
            color: ConstantsClass.getDefaultColor(),
          ),
        ),
      ),
    );
  }
}
