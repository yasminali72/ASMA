import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Views/AddMedicineDetailsScreen/add_medicine_details_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push.dart';
import 'Medicine_List_Item/medicine_item_card.dart';

class MedicineListItem extends StatelessWidget {
  final int index;
  final bool main;
  const MedicineListItem({Key? key, required this.index, required this.main})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<MedicineModel> medicines = MedicineCubit.get(context).getMedicine();

    return InkWell(
      onTap: () {
        MedicineCubit.get(context).updateRemainingMedicine(
            double.parse(medicines[index].counterSize));
        buildPush(
            context,
            AddMedicineDetailsScreen(
              medicineModel: medicines[index],
              type: main == false ? 'rescue' : 'regular',
            ));
      },
      child: MedicineItemCard(
        index: index,
      ),
    );
  }
}
