import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Medicine_List_Screen/Medicine_Search_Container/medicine_search_text_field.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';

class MedicineSearchContainer extends StatelessWidget {
  const MedicineSearchContainer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border:
              Border.all(color: ConstantsClass.getDefaultColor(), width: 1.4)),
      child: Row(
        children: [
          Icon(
            Icons.search,
            color: ConstantsClass.getDefaultColor(),
          ),
          const BuildSizedBox(width: 5,),
          const Expanded(child: MedicineSearchTextField())
        ],
      ),
    );
  }
}
