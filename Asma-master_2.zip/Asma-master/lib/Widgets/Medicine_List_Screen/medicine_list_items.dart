import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'Medicine_List_Items/medicine_list_item.dart';

class MedicineListItems extends StatelessWidget {
  final bool main;
  const MedicineListItems({Key? key, required this.main}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      builder: (_, __) => ListView.builder(
        itemBuilder: (_, index) => MedicineListItem(
          main: main,
          index: index,
        ),
        itemCount: MedicineCubit.get(context).getMedicine().length,
      ),
    );
  }
}
