import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Shared_Widgets/show_dialog_action.dart';

speedDialChildWidget({required String label, required BuildContext context}) {
  Color color = label == "Rescue"
      ? Colors.red.withOpacity(.6)
      : Colors.green.withOpacity(.6);
  MedicineCubit medicineCubit = MedicineCubit.get(context);
  String image = medicineCubit
      .getLocalMedicineById(label == "Rescue"
          ? medicineCubit.rescuePatientMedicine?.medicineId ?? 0
          : medicineCubit.regularPatientMedicine?.medicineId ?? 0)
      .image;
  return SpeedDialChild(
    onTap: () {
      showDialogActionWidget(context, label, "Increase usages of $label?", () {
        medicineCubit.increaseDoses(label).then((value) {
          Navigator.pop(context);
        });
      });
    },
    labelStyle: TextStyle(color: color, fontWeight: FontWeight.bold),
    label: label,
    child: Stack(
      alignment: Alignment.topRight,
      children: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: SizedBox(
              height: 20,
              child: Image(image: AssetImage("assets/images/$image"))),
        ),
        Icon(Icons.add, size: 20, color: color)
      ],
    ),
  );
}
