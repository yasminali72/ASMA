import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/ViewModels/Cubit/Navigation/navigation_cubit.dart';
import 'package:asma/ViewModels/Cubit/Navigation/navigation_states.dart';
import 'package:asma/Widgets/Shared_Widgets/build_snack_bar.dart';
import 'Floating_Action_Button/speed_dial_child_widget.dart';

class FloatingActionButtonWidget extends StatelessWidget {
  const FloatingActionButtonWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    NavigationCubit navigationCubit = NavigationCubit.get(context);
    return BlocListener<MedicineCubit, MedicineStates>(
      listenWhen: (_, current) =>
          current is IncreaseDosesSuccess || current is IncreaseDosesError,
      listener: (BuildContext context, state) {
        if (state is IncreaseDosesSuccess) {
          showSnackBar(context, "Done successfully");
        } else {
          showSnackBar(context, "All required doses already done");
        }
      },
      child: BlocBuilder<NavigationCubit, NavigationStates>(
        buildWhen: (_, current) => current is SpeedDialChanged,
        builder: (_, __) => SpeedDial(
          onOpen: () {
            navigationCubit.updateSpeedDialIOpened(true);
          },
          onClose: () {
            navigationCubit.updateSpeedDialIOpened(false);
          },
          backgroundColor: ConstantsClass.getDefaultColor(),
          direction: SpeedDialDirection.up,
          children: [
            speedDialChildWidget(label: "Rescue", context: context),
            speedDialChildWidget(label: "Regular", context: context),
          ],
          child:
              Icon(navigationCubit.speedDialOpened ? Icons.close : Icons.add),
        ),
      ),
    );
  }
}
