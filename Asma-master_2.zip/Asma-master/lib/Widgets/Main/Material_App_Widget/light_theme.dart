import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';

lightTheme() {
  return ThemeData(
    textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all(
                ConstantsClass.getDarkDefaultColor()))),
    timePickerTheme: TimePickerThemeData(
        hourMinuteTextColor: MaterialStateColor.resolveWith((states) =>
            states.contains(MaterialState.selected)
                ? ConstantsClass.getLightDefaultColor()
                : ConstantsClass.getDefaultColor()),
        dayPeriodTextColor: ConstantsClass.getDarkDefaultColor(),
        dialBackgroundColor: ConstantsClass.getLightDefaultColor(),
        dialHandColor: ConstantsClass.getDefaultColor(),
        hourMinuteColor: MaterialStateColor.resolveWith((states) =>
            states.contains(MaterialState.selected)
                ? ConstantsClass.getDefaultColor()
                : ConstantsClass.getLightDefaultColor())),
  );
}
