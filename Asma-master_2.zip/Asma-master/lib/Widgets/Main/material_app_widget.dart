import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/Views/ConnectionScreen/connection_screen.dart';
import 'package:asma/Views/LayoutScreen/layout_screen.dart';
import 'package:asma/Views/MedicineSelectionScreen/medicine_selection_screen.dart';
import 'package:asma/Views/SgnUpScreen/sign_up_screen.dart';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:asma/Widgets/Main/Material_App_Widget/light_theme.dart';
import 'package:sizer/sizer.dart';

import '../../ViewModels/Cubit/Sensors/sensors_cubit.dart';

class MaterialAppWidget extends StatelessWidget {
  final SignInCubit signInCubit;
  final MedicineCubit medicineCubit;
  const MaterialAppWidget(
      {Key? key, required this.signInCubit, required this.medicineCubit})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return MultiBlocProvider(
        providers: [
          BlocProvider<MedicineCubit>(
              create: (_) => medicineCubit..getDoses(signInCubit.patient)),
          BlocProvider<SignInCubit>(create: (_) => signInCubit),
          BlocProvider<SensorsCubit>(
              create: (_) => SensorsCubit()..loadSensorsData())
        ],
        child: MaterialApp(
          theme: lightTheme(),
          debugShowCheckedModeBanner: false,
          builder: (context, child) => StreamBuilder<ConnectivityResult>(
            stream: Connectivity().onConnectivityChanged,
            builder: (context, snapshot) {
              if (snapshot.data == null) return child!;
              ConnectivityResult state = snapshot.data!;
              if (state.name == "wifi" || state.name == "mobile") {
                return child!;
              } else {
                return const ConnectionScreen();
              }
            },
          ),
          home: ConstantsClass.getUId() == null
              ? const SignUpScreen()
              : signInCubit.patient!.hasMedicine
                  ? const LayoutScreen()
                  : const MedicineSelectionScreen(),
        ),
      );
    });
  }
}
