import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';

class CoveredContainer extends StatelessWidget {
  const CoveredContainer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        color: ConstantsClass.getLightDefaultColor().withOpacity(.7),
      ),
    );
  }
}
