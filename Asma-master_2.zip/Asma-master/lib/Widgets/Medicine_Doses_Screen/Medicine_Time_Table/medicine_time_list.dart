import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class MedicineTimeList extends StatelessWidget {
  final List<String> listItems;
  const MedicineTimeList({Key? key, required this.listItems}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        child: ListView.separated(
          itemBuilder: (context, index) => Center(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: BoldText(
              text: listItems[index].toString(),
              fontsSize: 12.sp,
              color: ConstantsClass.getDarkDefaultColor(),
            ),
          )),
          itemCount: listItems.length,
          separatorBuilder: (BuildContext context, int index) => index == 0
              ? Container()
              : Divider(
                  thickness: 1.2,
                  color: ConstantsClass.getDarkDefaultColor(),
                ),
        ),
      ),
    );
  }
}
