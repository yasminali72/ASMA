import 'package:flutter/material.dart';
import 'package:asma/Widgets/Medicine_Doses_Screen/Doses_Numbr_And_Times/medicine_doses_counter.dart';
import 'package:asma/Widgets/Medicine_Doses_Screen/Doses_Numbr_And_Times/medicine_time_table.dart';

class DosesNumberAndTimes extends StatelessWidget {
  const DosesNumberAndTimes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Column(
        children: [
          MedicineDosesCounter(),
          MedicineTimeTable()
        ],
      ),
    );
  }
}
