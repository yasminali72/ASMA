import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';

class DosesDecrementButton extends StatelessWidget {
  const DosesDecrementButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IconButton(
        onPressed: () {
          MedicineCubit.get(context).dosesDecrement();
        },
        icon: Icon(
          Icons.remove_circle,
          size: 28,
          color: ConstantsClass.getDarkDefaultColor(),
        ));
  }
}
