import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';

class DosesIncrementButton extends StatelessWidget {
  const DosesIncrementButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IconButton(
        onPressed: () {
          MedicineCubit.get(context).dosesIncrement();
        },
        icon: Icon(
          Icons.add_circle_sharp,
          size: 28,
          color: ConstantsClass.getDarkDefaultColor(),
        ));
  }
}
