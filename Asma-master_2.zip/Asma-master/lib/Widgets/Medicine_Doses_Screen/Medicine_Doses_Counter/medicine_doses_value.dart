import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class MedicineDosesValue extends StatelessWidget {
  const MedicineDosesValue({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
        buildWhen: (_, current) => current is MedicineDosesChanged,
        builder: (context, state) => NormalText(
              text: MedicineCubit.get(context).numberOfDoses.toString(),
              fontsSize: 32,
            ));
  }
}
