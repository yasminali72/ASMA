import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'Reminer_Setting_Column/reminder_setting_item_card.dart';

class ReminderSettingColumn extends StatelessWidget {
  const ReminderSettingColumn({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return Column(
      children: [
        ReminderSettingItemCard(
          text: "Full Screen",
          switchValue: medicineCubit.fullScreen,
        ),
        ReminderSettingItemCard(
          text: "Sound",
          switchValue: medicineCubit.sound,
        ),
        ReminderSettingItemCard(
          text: "Vibration",
          switchValue: medicineCubit.vibration,
        ),
        ReminderSettingItemCard(
          text: "Silent",
          switchValue: medicineCubit.silent,
        ),
      ],
    );
  }
}
