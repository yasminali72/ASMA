import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class ReminderSettingItemCard extends StatelessWidget {
  final String text;
  final bool switchValue;
  const ReminderSettingItemCard(
      {Key? key, required this.text, required this.switchValue})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool switchValue = false;
    return Card(
      elevation: 0,
      shape: Border.all(color: Colors.grey.shade300),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                BoldText(text: text, fontsSize: 15.3),
                BlocBuilder<MedicineCubit, MedicineStates>(
                  builder: (_, __) => Switch(
                      value: switchValue,
                      activeColor: ConstantsClass.getDefaultColor(),
                      onChanged: (val) {
                        switchValue = val;
                        MedicineCubit.get(context)
                            .setDosesSettingValues(val, text);
                      }),
                )
              ],
            ),
            if (text == "Silent") ...[
              NormalText(
                text:
                    "Enabling Silent mode will prevent medication \n\nreminders from popping up",
                fontsSize: 13,
                color: Colors.grey.shade400,
              ),
              const BuildSizedBox(height: 10)
            ]
          ],
        ),
      ),
    );
  }
}
