import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import '../Medicine_Doses_Counter/medicine_doses_value.dart';
import '../Medicine_Doses_Counter/doses_increment_button.dart';
import '../Medicine_Doses_Counter/doses_decrement_button.dart';
import 'package:sizer/sizer.dart';

class MedicineDosesCounter extends StatelessWidget {
  const MedicineDosesCounter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          const BuildSizedBox(height: 20),
          BoldText(
            text: "Number of doses",
            fontsSize: 16.5,
            color: Colors.grey,
          ),
          const BuildSizedBox(height: 10),
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              DosesDecrementButton(),
              BuildSizedBox(width: 20),
              MedicineDosesValue(),
              BuildSizedBox(width: 20),
              DosesIncrementButton()
            ],
          )
        ],
      ),
    );
  }
}
