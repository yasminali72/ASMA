import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class MedicineTimeTable extends StatelessWidget {
  const MedicineTimeTable({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) =>
          current is MedicineDosesChanged ||
          current is MedicineDosesTimeSelected,
      builder: (context, state) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        height: medicineCubit.numberOfDoses * 50,
        child: ListView.builder(
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) => Row(
            children: [
              BoldText(
                text: "Reminder ${index + 1} :",
                fontsSize: 15,
              ),
              const BuildSizedBox(width: 5),
              BoldText(
                text: medicineCubit.getTimeOfDate(
                    medicineCubit.dosesReminder[index], context),
                fontsSize: 15,
                color: ConstantsClass.getDarkDefaultColor(),
              ),
              const Spacer(),
              IconButton(
                  onPressed: () async {
                    TimeOfDay? currentTime = await showTimePicker(
                      context: context,
                      initialTime: const TimeOfDay(
                        hour: 10,
                        minute: 0,
                      ),
                    );
                    medicineCubit.addDosesReminder(index, currentTime);
                  },
                  icon: Icon(
                    Icons.date_range_sharp,
                    color: ConstantsClass.getDarkDefaultColor(),
                  ))
            ],
          ),
          itemCount: medicineCubit.numberOfDoses,
        ),
      ),
    );
  }
}
