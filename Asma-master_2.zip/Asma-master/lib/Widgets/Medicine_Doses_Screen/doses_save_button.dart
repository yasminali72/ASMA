import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:sizer/sizer.dart';

class DosesSaveButton extends StatelessWidget {
  final String type;
  const DosesSaveButton({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocConsumer<MedicineCubit, MedicineStates>(
      listenWhen: (_, current) => current is ReminderAdded,
      buildWhen: (_, current) =>
          current is MedicineDosesTimeSelected ||
          current is MedicineDosesChanged,
      builder: (context, state) => SizedBox(
          width: 100.w - 48,
          child: BuildElevatedButton(
              text: "Save",
              onPressed: medicineCubit.isAllRemindersSelected()
                  ? () {
                      medicineCubit.addReminder(type, context);
                    }
                  : null,
              fontSize: 16)),
      listener: (_, __) {
        Navigator.pop(context);
      },
    );
  }
}
