import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/circular_indicator.dart';
import 'package:sizer/sizer.dart';

showDialogActionWidget(
    BuildContext context, String title, String message, Function() function) {
  showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          content: Text(
            message,
            style: TextStyle(fontSize: 13),
          ),
          title: Text(
            title,
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          actions: [
            BlocBuilder<MedicineCubit, MedicineStates>(
                buildWhen: (_, current) => current is IncreaseDosesLoading,
                builder: (context, state) => state is IncreaseDosesLoading
                    ? const SizedBox(height: 40, child: CircularIndicator())
                    : TextButton(onPressed: function, child: const Text("ok"))),
            TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("cancel")),
          ],
        );
      });
}
