import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:sizer/sizer.dart';

class BuildTextFormField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData? postFix;
  final TextInputType? keyboard;
  final bool? obscureText;
  final String? Function(String?)? validate;
  final Function()? showPassword;
  final Function(String)? onChange;

  const BuildTextFormField(
      {Key? key,
      required this.controller,
      required this.label,
      this.postFix,
      this.keyboard,
      this.obscureText,
      this.validate,
      this.showPassword,
      this.onChange})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      validator: validate,
      keyboardType: keyboard,
      onChanged: onChange,
      obscureText: obscureText ?? false,
      decoration: InputDecoration(
        label: Text(
          label,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: ConstantsClass.getDarkDefaultColor()),
        ),
        filled: true,
        errorBorder: InputBorder.none,
        fillColor: const Color(0xfff5fafc),
        isDense: true,
        focusedBorder: OutlineInputBorder(
          borderSide:
              BorderSide(color: ConstantsClass.getDefaultColor(), width: 1.5),
        ),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xffe3f5fc)),
        ),
        suffixIcon: InkWell(
          onTap: showPassword,
          child: Icon(
            postFix,
            color: ConstantsClass.getDefaultColor(),
          ),
        ),
      ),
    );
  }
}
