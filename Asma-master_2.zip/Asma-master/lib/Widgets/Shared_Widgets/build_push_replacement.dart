import 'package:flutter/material.dart';

void buildPushReplacement(BuildContext context, Widget screen) {
  Navigator.pushReplacement(
    context,
    MaterialPageRoute(
      fullscreenDialog: true,
      builder: (context) => screen,
    ),
  );
}
