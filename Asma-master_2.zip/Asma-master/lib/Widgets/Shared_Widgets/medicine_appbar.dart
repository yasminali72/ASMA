import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/log_out_button.dart';

medicineAppBar(BuildContext context, String title,
    {bool? centerTitle, bool? logOut, Color? color}) {
  return AppBar(
    elevation: 0,
    backgroundColor: Colors.white,
    title: Text(
      title,
      style: TextStyle(color: color ?? Colors.black),
    ),
    centerTitle: centerTitle,
    iconTheme: const IconThemeData(color: Colors.black),
    actions: [
      if (logOut != null && !SignInCubit.get(context).patient!.hasMedicine)
        const LogOutButton()
    ],
  );
}
