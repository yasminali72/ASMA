import 'package:flutter/cupertino.dart';

class NormalText extends StatelessWidget {
  final String text;
  final double fontsSize;
  final Color? color;
  const NormalText(
      {Key? key, required this.text, required this.fontsSize, this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(fontSize: fontsSize, color: color),
    );
  }
}
