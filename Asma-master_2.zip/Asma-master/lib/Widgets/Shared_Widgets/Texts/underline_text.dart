import 'package:flutter/cupertino.dart';

class UnderlineText extends StatelessWidget {
  final String text;
  final double fontsSize;
  const UnderlineText({Key? key, required this.text, required this.fontsSize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: fontsSize,
          decoration: TextDecoration.underline),
    );
  }
}
