import 'package:flutter/cupertino.dart';

class BoldText extends StatelessWidget {
  final String text;
  final double fontsSize;
  final Color? color;
  const BoldText(
      {Key? key, required this.text, required this.fontsSize, this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
          fontWeight: FontWeight.bold, fontSize: fontsSize, color: color),
    );
  }
}
