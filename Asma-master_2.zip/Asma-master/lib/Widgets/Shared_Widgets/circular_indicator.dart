import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';

class CircularIndicator extends StatelessWidget {
  const CircularIndicator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: CircularProgressIndicator(
      color: ConstantsClass.getDefaultColor(),
    ));
  }
}
