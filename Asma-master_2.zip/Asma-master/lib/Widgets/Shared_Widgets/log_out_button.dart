import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_states.dart';
import 'package:asma/Views/SgnUpScreen/sign_up_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push_replacement.dart';
import 'package:asma/Widgets/Shared_Widgets/circular_indicator.dart';

import '../../Helpers/work_manager_helper.dart';
import '../../ViewModels/Cubit/Medicine/medicine_cubit.dart';

class LogOutButton extends StatelessWidget {
  const LogOutButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SignInCubit, SignInStates>(
      listenWhen: (_, current) => current is SignOutSuccess,
      buildWhen: (_, current) => current is SignOutLoading,
      builder: (context, state) => state is! SignOutLoading
          ? IconButton(
              onPressed: () {
                SignInCubit.get(context).signOut();
              },
              icon: Icon(
                Icons.logout,
                color: ConstantsClass.getDarkDefaultColor(),
              ))
          : const CircularIndicator(),
      listener: (BuildContext context, SignInStates state) {
        buildPushReplacement(context, const SignUpScreen());
        MedicineCubit.get(context).closeStreams();
        WorkManagerHelper.cancelAllTasks();
      },
    );
  }
}
