import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';

class BuildElevatedButton extends StatelessWidget {
  final double fontSize;
  final bool? empty;
  final String text;
  final void Function()? onPressed;

  const BuildElevatedButton(
      {super.key,
      required this.text,
      required this.onPressed,
      this.empty,
      required this.fontSize});
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        style: ButtonStyle(
            elevation: MaterialStateProperty.all(0),
            padding: MaterialStateProperty.all(const EdgeInsets.all(8)),
            backgroundColor: MaterialStateProperty.all(empty != null
                ? Colors.white
                : ConstantsClass.getDefaultColor()),
            shape: MaterialStateProperty.all(RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5),
                side: BorderSide(
                    color: ConstantsClass.getDefaultColor().withOpacity(.3))))),
        onPressed: onPressed,
        child: BoldText(
          text: text,
          fontsSize: fontSize,
          color: onPressed != null
              ? empty != null
                  ? ConstantsClass.getDefaultColor()
                  : Colors.white
              : Colors.grey,
        ));
  }
}
