import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class TopScreenPart extends StatelessWidget {
  final String text;
  const TopScreenPart({Key? key, required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Spacer(flex: 1),
        Expanded(
            flex: 2,
            child: Image(
              image: const AssetImage("assets/images/azma.png"),
              width: 50.w,
            )),
        Expanded(
            flex: 1,
            child: BoldText(
              text: text,
              fontsSize: 32,
            ))
      ],
    );
  }
}
