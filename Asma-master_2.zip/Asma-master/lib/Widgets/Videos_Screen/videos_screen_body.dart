import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Videos_Screen/Videos_Screen_Body/map_body_widget.dart';
import 'Videos_Screen_Body/doctor_body_widget.dart';
import 'Videos_Screen_Body/videos_body_widget.dart';

class VideosScreenBody extends StatelessWidget {
  const VideosScreenBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is UpdateVideosTopButtonIndex,
      builder: (context, state) => Container(
        padding: const EdgeInsets.all(15),
        child: medicineCubit.videosTopButtonIndex == 0
            ? const VideosBodyWidget()
            : medicineCubit.videosTopButtonIndex == 2
                ? const DoctorBodyWidget()
                : const MapBodyWidget(),
      ),
    );
  }
}
