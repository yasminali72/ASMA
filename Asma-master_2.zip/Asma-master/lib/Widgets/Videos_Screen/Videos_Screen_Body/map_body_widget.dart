import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapBodyWidget extends StatelessWidget {
  const MapBodyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: const GoogleMap(
        mapType: MapType.normal,
        initialCameraPosition: CameraPosition(
          bearing: 192.8334901395799,
          target: LatLng(31.040948, 31.378470),
          zoom: 13,
        ),
      ),
    );
  }
}
