import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:asma/Widgets/Videos_Screen/Videos_Screen_Body/Videos_Body_Widget/video_widget.dart';
import 'package:sizer/sizer.dart';
import 'Videos_Body_Widget/video_title.dart';

class VideosBodyWidget extends StatelessWidget {
  const VideosBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int videoNumber = 0;
    return SingleChildScrollView(
      child: Column(
        children: ConstantsClass.getVideos()
            .map((video) => Column(
                  children: [
                    VideoTitle(
                      videoNumber: ++videoNumber,
                      videoId: video.id,
                      videoTitle: video.title,
                    ),
                    SizedBox(
                      height: 45.w,
                      width: 85.w,
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: VideoWidget(
                            videoId: video.id,
                          )),
                    ),
                    const BuildSizedBox(height: 30)
                  ],
                ))
            .toList(),
      ),
    );
  }
}
