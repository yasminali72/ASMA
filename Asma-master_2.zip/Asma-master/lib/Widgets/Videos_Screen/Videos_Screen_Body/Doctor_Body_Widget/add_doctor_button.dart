import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';

class AddDoctorButton extends StatelessWidget {
  const AddDoctorButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color color = ConstantsClass.getDefaultColor();
    return TextButton.icon(
        style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all(
              color,
            ),
            padding: MaterialStateProperty.all(
              const EdgeInsets.symmetric(horizontal: 10),
            ),
            shape: MaterialStateProperty.all(
              RoundedRectangleBorder(
                  side: BorderSide(color: color, width: 1.4),
                  borderRadius: BorderRadius.circular(20)),
            )),
        onPressed: () {},
        icon: const Icon(Icons.add),
        label: const BoldText(text: "Add New", fontsSize: 15));
  }
}
