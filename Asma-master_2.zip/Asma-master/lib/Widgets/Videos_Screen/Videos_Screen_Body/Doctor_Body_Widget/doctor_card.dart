import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class DoctorCard extends StatelessWidget {
  const DoctorCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.w,
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
            side: BorderSide(color: Colors.grey.withOpacity(.1), width: 1.4),
            borderRadius: BorderRadius.circular(6)),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 50),
          child: Column(
            children: [
              const SizedBox(
                height: 80,
                child: Image(
                  image: AssetImage("assets/images/doctor.png"),
                  fit: BoxFit.fill,
                ),
              ),
              const BuildSizedBox(height: 10),
              BoldText(
                text: "No doctor added yet",
                fontsSize: 16.7,
              ),
              const BuildSizedBox(height: 5),
              BoldText(
                text:
                    "To add your doctor, please \nselect Add New button above",
                fontsSize: 15,
                color: Colors.grey.shade400.withOpacity(.9),
              )
            ],
          ),
        ),
      ),
    );
  }
}
