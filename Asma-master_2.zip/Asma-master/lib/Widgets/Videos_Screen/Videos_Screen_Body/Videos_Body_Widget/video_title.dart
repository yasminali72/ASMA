import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Videos_Screen/Videos_Screen_Body/Videos_Body_Widget/video_info.dart';
import 'package:sizer/sizer.dart';

class VideoTitle extends StatelessWidget {
  final int videoNumber;
  final String videoId;
  final String videoTitle;
  const VideoTitle(
      {Key? key,
      required this.videoNumber,
      required this.videoId,
      required this.videoTitle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: ConstantsClass.getDefaultColor(),
        foregroundColor: Colors.white,
        radius: 16,
        child: Text(videoNumber.toString()),
      ),
      title: BoldText(
        text: "Module $videoNumber",
        fontsSize: 16.5,
      ),
      subtitle: VideoInfo(videoTitle: videoTitle),
    );
  }
}
