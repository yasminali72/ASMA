import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

class WatchVideoOnYoutube extends StatelessWidget {
  final String videoId;
  const WatchVideoOnYoutube({Key? key, required this.videoId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(3),
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.4),
        borderRadius: BorderRadius.circular(7)
      ),
      child: InkWell(
        onTap: () {
           launch("https://youtu.be/$videoId");
        },
        child: BoldText(
          text: "watch on youtube",
          fontsSize: 14.5,
          color: Colors.red.shade500,
        ),
      ),
    );
  }
}
