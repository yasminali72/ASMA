import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Videos_Screen/Videos_Screen_Body/Videos_Body_Widget/watch_video_on_youtube.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class VideoWidget extends StatelessWidget {
  final String videoId;
  const VideoWidget({super.key, required this.videoId});

  @override
  Widget build(BuildContext context) {
    late YoutubePlayerController controller;
    controller = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: false,
      ),
    );
    return Padding(
      padding: const EdgeInsets.all(3.5),
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          YoutubePlayer(
            controller: controller,
            bottomActions: [
              CurrentPosition(),
              ProgressBar(
                isExpanded: true,
                colors: ProgressBarColors(
                    playedColor: ConstantsClass.getDarkDefaultColor(),
                    backgroundColor: ConstantsClass.getLightDefaultColor(),
                    bufferedColor: ConstantsClass.getDefaultColor(),
                    handleColor: ConstantsClass.getDefaultColor()),
              ),
              RemainingDuration(),
              PlaybackSpeedButton(
                icon: Icon(
                  Icons.speed,
                  color: ConstantsClass.getDefaultColor(),
                ),
              ),
            ],
          ),
          WatchVideoOnYoutube(videoId: videoId),
        ],
      ),
    );
  }
}
