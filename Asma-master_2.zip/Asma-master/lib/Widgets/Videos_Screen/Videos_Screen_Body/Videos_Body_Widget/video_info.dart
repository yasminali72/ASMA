import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class VideoInfo extends StatelessWidget {
  final String videoTitle;
  const VideoInfo({Key? key, required this.videoTitle}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BoldText(
      text: videoTitle,
      fontsSize: 14.5,
    );
  }
}
