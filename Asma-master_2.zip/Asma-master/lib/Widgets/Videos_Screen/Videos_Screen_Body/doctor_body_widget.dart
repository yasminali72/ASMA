import 'package:flutter/material.dart';
import 'Doctor_Body_Widget/add_doctor_button.dart';
import 'Doctor_Body_Widget/doctor_card.dart';

class DoctorBodyWidget extends StatelessWidget {
  const DoctorBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          AddDoctorButton(),
          DoctorCard(),
        ],
      ),
    );
  }
}
