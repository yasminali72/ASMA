import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Videos_Screen/Videos_Top_Buttons/videos_button_container.dart';

class VideosTopButtons extends StatelessWidget {
  const VideosTopButtons({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 12),
      height: 35,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: ConstantsClass.getDefaultColor()),
        borderRadius: BorderRadius.circular(40),
      ),
      child: const Row(
        children: [
          VideosButtonContainer(currentIndex: 0),
          VideosButtonContainer(currentIndex: 1),
          VideosButtonContainer(currentIndex: 2),
        ],
      ),
    );
  }
}
