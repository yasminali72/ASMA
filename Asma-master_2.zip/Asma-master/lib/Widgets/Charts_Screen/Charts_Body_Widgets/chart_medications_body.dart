import 'package:flutter/material.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Medications_Body/Chart_Data_Widget/chart_title.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Medications_Body/rescue_chart_widget.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Medications_Body/regular_chart_widget.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';

class ChartMedicationsBody extends StatelessWidget {
  const ChartMedicationsBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(15.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ChartTitleWidget(type: "Rescue Medications"),
            BuildSizedBox(height: 10),
            RescueChartWidget(),
            BuildSizedBox(height: 30),
            ChartTitleWidget(type: "Regular Medications"),
            BuildSizedBox(height: 10),
            RegularChartWidget(),
            BuildSizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
