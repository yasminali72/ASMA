import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Medications_Body/Chart_Data_Widget/chart_data_widget.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Medications_Body/Chart_Data_Widget/chart_widget.dart';

class RescueChartWidget extends StatelessWidget {
  const RescueChartWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    MedicineModel medicineModel = medicineCubit.getRescueMedicine();

    return Card(
      elevation: 0,
      shape: OutlineInputBorder(
          borderSide:
              BorderSide(color: Colors.grey.withOpacity(.1), width: 1.4),
          borderRadius: BorderRadius.circular(7)),
      child: Column(
        children: [
          ChartDataWidget(
            medicineModel: medicineModel,
            medicineType: "Rescue",
          ),
          const ChartWidget(regular: false)
        ],
      ),
    );
  }
}
