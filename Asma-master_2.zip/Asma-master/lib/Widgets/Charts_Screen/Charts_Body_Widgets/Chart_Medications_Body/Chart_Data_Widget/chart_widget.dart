import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/Models/chart_model.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:sizer/sizer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ChartWidget extends StatelessWidget {
  final bool regular;
  const ChartWidget({Key? key, required this.regular}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is IncreaseDosesSuccess,
      builder: (context, state) => SizedBox(
        height: 40.w,
        width: 70.w,
        child: SfCartesianChart(
            palette: [ConstantsClass.getDefaultColor()],
            primaryXAxis: CategoryAxis(
              labelStyle: TextStyle(
                  color: Colors.grey.shade800,
                  fontWeight: FontWeight.bold,
                  fontSize: 10.5),
              labelRotation: 45,
              minorTicksPerInterval: 3,
            ),
            series: <LineSeries<ChartModel, String>>[
              LineSeries<ChartModel, String>(
                  dataSource: <ChartModel>[
                    ...MedicineCubit.get(context).getFigureData(regular)
                  ],
                  xValueMapper: (ChartModel read, _) => read.date,
                  yValueMapper: (ChartModel read, _) => read.value)
            ]),
      ),
    );
  }
}
