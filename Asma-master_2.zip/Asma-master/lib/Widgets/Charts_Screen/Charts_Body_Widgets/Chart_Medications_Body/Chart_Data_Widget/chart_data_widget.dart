import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Medications_Body/Chart_Data_Widget/Charts_Data_Widget/chart_doses_times.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class ChartDataWidget extends StatelessWidget {
  final MedicineModel medicineModel;
  final String medicineType;
  const ChartDataWidget(
      {Key? key, required this.medicineModel, required this.medicineType})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: SizedBox(
            height: 35,
            child: Image(
              image: AssetImage("assets/images/${medicineModel.image}"),
            ),
          ),
          title: BoldText(text: medicineModel.name, fontsSize: 16
          ),
          subtitle: Text(medicineType),
        ),
        const BuildSizedBox(height: 5),
        ChartDosesTimes(regular: medicineType == "Regular" ? true : false),
        const BuildSizedBox(height: 15),
      ],
    );
  }
}
