import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/normal_text.dart';
import 'package:sizer/sizer.dart';

class ChartDosesTimes extends StatelessWidget {
  final bool regular;
  const ChartDosesTimes({super.key, required this.regular});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is IncreaseDosesSuccess,
      builder: (context, state) => NormalText(
        text:
            "Over the last 7 days, you have used it for ${MedicineCubit.get(context).getDosesFigureCount(regular)} times",
        fontsSize: 13,
        color: Colors.grey,
      ),
    );
  }
}
