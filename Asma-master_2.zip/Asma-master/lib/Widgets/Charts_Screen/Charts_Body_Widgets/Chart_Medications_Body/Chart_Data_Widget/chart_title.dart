import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:sizer/sizer.dart';

class ChartTitleWidget extends StatelessWidget {
  final String type;
  const ChartTitleWidget({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BoldText(text: type, fontsSize: 18);
  }
}
