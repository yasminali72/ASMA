import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:asma/ViewModels/Cubit/Sensors/sensors_states.dart';
import 'package:asma/Widgets/Shared_Widgets/circular_indicator.dart';
import 'package:flutter/material.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Measures_Body/dust_chart_widget.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'Chart_Measures_Body/air_chart_widget.dart';
import 'Chart_Measures_Body/humidity_chart_widget.dart';
import 'Chart_Measures_Body/temperature_chart_widget.dart';

class ChartMeasuresBody extends StatelessWidget {
  const ChartMeasuresBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SensorsCubit, SensorsStates>(
      builder: (context, state) => state is SensorsDataLoading
          ? CircularIndicator()
          : Padding(
              padding: const EdgeInsets.all(15.0),
              child: SizedBox(
                width: 100.w,
                child: SingleChildScrollView(
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      HumidityChartWidget(),
                      BuildSizedBox(height: 20),
                      DustChartWidget(),
                      BuildSizedBox(height: 20),
                      AirChartWidget(),
                      BuildSizedBox(height: 20),
                      TemperatureChartWidget(),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}
