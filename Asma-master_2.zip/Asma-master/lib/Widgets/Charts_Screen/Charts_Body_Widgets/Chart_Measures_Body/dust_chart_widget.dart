import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/Models/chart_model.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'Chart_Data_Widget/spline_chart_widget.dart';
import 'package:sizer/sizer.dart';

class DustChartWidget extends StatelessWidget {
  const DustChartWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<ChartModel> reads = SensorsCubit.get(context).dustCharts;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BoldText(text: "Dust", fontsSize: 18),
        const BuildSizedBox(height: 15),
        Center(child: SplineChartWidget(reads: reads))
      ],
    );
  }
}
