import 'package:asma/ViewModels/Cubit/Sensors/sensors_cubit.dart';
import 'package:flutter/material.dart';
import 'package:asma/Models/chart_model.dart';
import 'package:asma/Widgets/Charts_Screen/Charts_Body_Widgets/Chart_Measures_Body/Chart_Data_Widget/column_chart_widget.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class HumidityChartWidget extends StatelessWidget {
  const HumidityChartWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<ChartModel> reads = SensorsCubit.get(context).humidityCharts;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BoldText(text: "Humidity", fontsSize: 18),
        const BuildSizedBox(height: 15),
        Center(child: ColumnChartWidget(reads: reads))
      ],
    );
  }
}
