import 'package:flutter/material.dart';
import 'package:asma/Models/chart_model.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:sizer/sizer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class SplineChartWidget extends StatelessWidget {
  final List<ChartModel> reads;
  const SplineChartWidget({Key? key, required this.reads}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50.w,
      width: 70.w,
      child: SfCartesianChart(
          palette: [ConstantsClass.getDefaultColor()],
          primaryXAxis: CategoryAxis(
            desiredIntervals: 10,
            labelStyle: TextStyle(
                color: Colors.grey.shade800,
                fontWeight: FontWeight.bold,
                fontSize: 10.5),
            labelRotation: 45,
            minorTicksPerInterval: 3,
          ),
          series: <SplineAreaSeries<ChartModel, String>>[
            SplineAreaSeries<ChartModel, String>(
                dataSource: <ChartModel>[...reads],
                xValueMapper: (ChartModel read, _) => read.date,
                yValueMapper: (ChartModel read, _) => read.value)
          ]),
    );
  }
}
