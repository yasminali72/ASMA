import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'Charts_Body_Widgets/chart_measures_body.dart';
import 'Charts_Body_Widgets/chart_medications_body.dart';

class ChartsBodyWidget extends StatelessWidget {
  const ChartsBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MedicineCubit, MedicineStates>(
      buildWhen: (_, current) => current is UpdateChartsTopButtonIndex,
      builder: (context, state) => Container(
        child: MedicineCubit.get(context).chartsTopButtonIndex == 0
            ? const ChartMedicationsBody()
            : const ChartMeasuresBody(),
      ),
    );
  }
}
