import 'package:flutter/material.dart';
import 'package:asma/Models/added_medicine_model.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'Medicine_Data_Item/medicine_title.dart';
import 'Medicine_Data_Item/medicine_data_card.dart';

class MedicineDataItem extends StatelessWidget {
  final String title;
  final AddedMedicineModel addedMedicineModel;
  const MedicineDataItem(
      {Key? key, required this.title, required this.addedMedicineModel})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        MedicineTitle(
          title: title,
        ),
        const BuildSizedBox(height: 5),
        MedicineDataCard(
          addedMedicineModel: addedMedicineModel,
          regular: title == "Regular" ? true : false,
        )
      ],
    );
  }
}
