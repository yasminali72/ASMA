import 'package:flutter/material.dart';
import 'package:asma/Models/added_medicine_model.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Medicine_Screen/Medicine_Data_Item/Medicine_Data_Card/medicine_image.dart';
import 'package:asma/Widgets/Medicine_Screen/Medicine_Data_Item/Medicine_Data_Card/medicine_today_usages.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';
import 'Medicine_Data_Card/medicine_data_item_text.dart';

class MedicineDataCard extends StatelessWidget {
  final bool regular;
  final AddedMedicineModel addedMedicineModel;
  const MedicineDataCard(
      {Key? key, required this.addedMedicineModel, required this.regular})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineModel medicineModel = MedicineCubit.get(context)
        .getLocalMedicineById(addedMedicineModel.medicineId);
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
          side: BorderSide(color: Colors.grey.withOpacity(.1), width: 1.4)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0),
        child: Row(
          children: [
            MedicineImage(
              medicineImage: medicineModel.image,
            ),
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BoldText(
                    text: medicineModel.name,
                    fontsSize: 16,
                    color: ConstantsClass.getDefaultColor(),
                  ),
                  const BuildSizedBox(height: 5),
                  const MedicineDataItemText(
                      title: "Tracking:", value: "Manually"),
                  MedicineTodayUsages(regular: regular),
                  MedicineDataItemText(
                      title: "Usages left:",
                      value:
                          "${addedMedicineModel.remainingUsages.toInt()}/${medicineModel.counterSize}"),
                  if (regular)
                    MedicineDataItemText(
                        title: "Reminder:",
                        value: MedicineCubit.get(context)
                            .getRegularReminderTime()),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
