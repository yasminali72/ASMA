import 'package:flutter/material.dart';

class MedicineImage extends StatelessWidget {
  final String medicineImage;
  const MedicineImage({super.key, required this.medicineImage});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SizedBox(
          height: 50,
          child: Image(
            image: AssetImage('assets/images/$medicineImage'),
          ),
        ),
      ),
    );
  }
}
