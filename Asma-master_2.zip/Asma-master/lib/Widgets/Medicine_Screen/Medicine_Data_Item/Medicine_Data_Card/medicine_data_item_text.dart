import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class MedicineDataItemText extends StatelessWidget {
  final String title;
  final String value;
  const MedicineDataItemText(
      {Key? key, required this.title, required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: [
          BoldText(
            text: title,
            fontsSize: 15,
            color: Colors.grey.shade800,
          ),
          const BuildSizedBox(
            width: 10,
          ),
          Expanded(
            child: BoldText(
              text: value,
              fontsSize: 15,
              color: Colors.grey.shade700,
            ),
          ),
        ],
      ),
    );
  }
}
