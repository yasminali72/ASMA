import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Medicine_Screen/Medicine_Data_Item/Medicine_Data_Card/medicine_data_item_text.dart';

class MedicineTodayUsages extends StatelessWidget {
  final bool regular;
  const MedicineTodayUsages({super.key, required this.regular});

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return BlocBuilder<MedicineCubit, MedicineStates>(
      builder: (context, state) => MedicineDataItemText(
          title: "Today's usages:",
          value: regular
              ? medicineCubit.getTodayRegularDosesLocal().toString()
              : medicineCubit.getTodayRescueDosesLocal().toString()),
    );
  }
}
