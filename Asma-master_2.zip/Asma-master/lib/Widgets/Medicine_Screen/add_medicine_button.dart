import 'package:flutter/material.dart';
import 'package:asma/Views/MedicineSelectionScreen/medicine_selection_screen.dart';
import 'package:asma/Widgets/Shared_Widgets/Buttons/build_elevated_button.dart';
import 'package:asma/Widgets/Shared_Widgets/build_push.dart';
import 'package:sizer/sizer.dart';

class AddMedicineButton extends StatelessWidget {
  const AddMedicineButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 90.w,
      height: 40,
      child: BuildElevatedButton(
        text: "Add another  medicine",
        onPressed: () {
          buildPush(context, const MedicineSelectionScreen());
        },
        fontSize: 16,
        empty: true,
      ),
    );
  }
}
