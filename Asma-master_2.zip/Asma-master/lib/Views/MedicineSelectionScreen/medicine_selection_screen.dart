import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Medicine_Selection_Screen/medicine_next_button.dart';
import 'package:asma/Widgets/Medicine_Selection_Screen/medicine_selection_item.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import '../../Widgets/Shared_Widgets/medicine_appbar.dart';

class MedicineSelectionScreen extends StatelessWidget {
  const MedicineSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: medicineAppBar(context, "Your Medications",
          logOut: true, color: ConstantsClass.getDarkDefaultColor()),
      body: const Padding(
        padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15),
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    MedicineSelectionItem(
                      main: false,
                    ),
                    BuildSizedBox(
                      height: 25,
                    ),
                    MedicineSelectionItem(
                      main: true,
                    ),
                  ],
                ),
              ),
            ),
            MedicineNextButton()
          ],
        ),
      ),
    );
  }
}
