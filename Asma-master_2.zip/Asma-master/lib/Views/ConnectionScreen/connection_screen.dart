import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/Widgets/Shared_Widgets/Texts/bold_text.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:sizer/sizer.dart';

class ConnectionScreen extends StatelessWidget {
  const ConnectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: 100.w,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
                width: 60.w,
                height: 250,
                child: SvgPicture.asset("assets/images/connection.svg")),
            const BuildSizedBox(height: 20),
            BoldText(
              text: "There is no network connection",
              fontsSize: 16.5,
              color: ConstantsClass.getDefaultColor(),
            )
          ],
        ),
      ),
    );
  }
}
