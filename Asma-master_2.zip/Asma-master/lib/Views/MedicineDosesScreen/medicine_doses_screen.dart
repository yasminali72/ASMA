import 'package:flutter/material.dart';
import 'package:asma/Widgets/Medicine_Doses_Screen/doses_number_and_times.dart';
import 'package:asma/Widgets/Medicine_Doses_Screen/reminder_setting_column.dart';
import 'package:asma/Widgets/Medicine_Doses_Screen/doses_save_button.dart';
import 'package:asma/Widgets/Shared_Widgets/medicine_appbar.dart';

class MedicineDosesScreen extends StatelessWidget {
  final String type;
  const MedicineDosesScreen(
      {Key? key, required this.type})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: medicineAppBar(context, "Reminders", centerTitle: true),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              const DosesNumberAndTimes(),
              const ReminderSettingColumn(),
              DosesSaveButton(
                type: type,
              )
            ],
          ),
        ),
      ),
    );
  }
}
