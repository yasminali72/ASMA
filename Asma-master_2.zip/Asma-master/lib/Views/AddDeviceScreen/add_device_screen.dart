import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/medicine_appbar.dart';
import '../../Widgets/Add_Device/add_device_body.dart';
class AddDeviceScreen extends StatelessWidget {
  const AddDeviceScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: medicineAppBar(context, "Add device"),
      body: const AddDeviceBody(),
    );
  }
}
