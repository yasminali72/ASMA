import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Cubit/SignUp/sign_up_cubit.dart';
import '../../Widgets/Shared_Widgets/Sign_Top_Part/top_screen_part.dart';
import '../../Widgets/Sign_Up_Screen/sign_up_form.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SignUpCubit>(
      create: (_) => SignUpCubit(),
      child: const Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              flex: 3,
              child: TopScreenPart(
                text: "Sign Up",
              ),
            ),
            Expanded(
              flex: 7,
              child: SignUpForm(),
            )
          ],
        ),
      ),
    );
  }
}
