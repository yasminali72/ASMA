import 'package:flutter/material.dart';
import 'package:asma/Widgets/Shared_Widgets/Sign_Top_Part/top_screen_part.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import '../../Widgets/Sign_In_Screen/sign_in_form.dart';

class SignInScreen extends StatelessWidget {
  const SignInScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          BuildSizedBox(
            height: 10,
          ),
          Expanded(
            flex: 1,
            child: TopScreenPart(
              text: "Sign In",
            ),
          ),
          BuildSizedBox(
            height: 20,
          ),
          Expanded(
            flex: 2,
            child: SignInForm(),
          )
        ],
      ),
    );
  }
}
