import 'package:flutter/material.dart';
import 'package:asma/Widgets/Medicine_List_Screen/medicine_list_items.dart';
import 'package:asma/Widgets/Medicine_List_Screen/medicine_search_container.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import '../../Widgets/Shared_Widgets/medicine_appbar.dart';

class MedicineListScreen extends StatelessWidget {
  final bool main;
  const MedicineListScreen({Key? key, required this.main}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: medicineAppBar(context, "Your Medications"),
      body: Column(
        children: [
          const MedicineSearchContainer(),
          const BuildSizedBox(height: 10),
          Expanded(child: MedicineListItems(main: main)),
        ],
      ),
    );
  }
}
