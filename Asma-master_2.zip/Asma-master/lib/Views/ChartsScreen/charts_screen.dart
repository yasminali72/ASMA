import 'package:flutter/material.dart';
import 'package:asma/Widgets/Charts_Screen/charts_body_widgets.dart';
import 'package:asma/Widgets/Charts_Screen/charts_top_buttons.dart';

class ChartsScreen extends StatelessWidget {
  const ChartsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SafeArea(
      child: Column(
        children: [
          ChartsTopButtons(),
          Expanded(child: ChartsBodyWidget()),
        ],
      ),
    );
  }
}
