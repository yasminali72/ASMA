import 'package:flutter/material.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/Widgets/Medicine_Screen/add_medicine_button.dart';
import 'package:asma/Widgets/Shared_Widgets/build_sized_box.dart';
import 'package:asma/Widgets/Shared_Widgets/medicine_appbar.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../ViewModels/Cubit/Medicine/medicine_states.dart';
import '../../Widgets/Medicine_Screen/medicine_data_item.dart';

class MedicineScreen extends StatelessWidget {
  const MedicineScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    MedicineCubit medicineCubit = MedicineCubit.get(context);
    return Scaffold(
      appBar: medicineAppBar(context, "My Medications",
          color: ConstantsClass.getDefaultColor()),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: SingleChildScrollView(
          child: BlocBuilder<MedicineCubit, MedicineStates>(
            buildWhen: (_, current)=> current is PatientMedicineLoaded,
            builder:(context, state)=> Column(
              children: [
                MedicineDataItem(
                  title: 'Rescue',
                  addedMedicineModel: medicineCubit.rescuePatientMedicine!,
                ),
                const BuildSizedBox(height: 30),
                MedicineDataItem(
                  title: 'Regular',
                  addedMedicineModel: medicineCubit.regularPatientMedicine!,
                ),
                const BuildSizedBox(height: 30),
                const AddMedicineButton()
              ],
            ),
          ),
        ),
      ),
    );
  }
}
