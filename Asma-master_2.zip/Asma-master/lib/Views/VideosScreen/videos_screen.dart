import 'package:flutter/material.dart';
import 'package:asma/Widgets/Videos_Screen/videos_screen_body.dart';
import 'package:asma/Widgets/Videos_Screen/videos_top_buttons.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SafeArea(
        child: Column(
      children: [
        VideosTopButtons(),
        Expanded(child: VideosScreenBody()),
      ],
    ));
  }
}
