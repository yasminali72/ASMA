import 'package:flutter/material.dart';
import 'package:asma/Models/medicine_model.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/medicine_details_card.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/medicine_planned_usages.dart';
import 'package:asma/Widgets/Add_Medicine_Details_Screen/medicine_remaning_usages.dart';
import '../../Widgets/Add_Medicine_Details_Screen/medicine_counter_card.dart';
import '../../Widgets/Add_Medicine_Details_Screen/confirm_button.dart';
import '../../Widgets/Add_Medicine_Details_Screen/cancel_button.dart';
import 'package:asma/Widgets/Shared_Widgets/medicine_appbar.dart';

class AddMedicineDetailsScreen extends StatelessWidget {
  final String type;
  final MedicineModel medicineModel;
  const AddMedicineDetailsScreen(
      {Key? key, required this.medicineModel, required this.type})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: medicineAppBar(
          context, "Add ${medicineModel.name.split(" ").first}",
          centerTitle: true),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
        child: SingleChildScrollView(
          child: Column(
            children: [
              MedicineDetailsCard(
                medicineModel: medicineModel,
              ),
              MedicineCounterCard(counterSize: medicineModel.counterSize),
              MedicineRemainingUsage(counterSize: medicineModel.counterSize),
              if(type == "regular")
              MedicinePlannedUsages(type: type),
              ConfirmButton(medicineId: medicineModel.id, type: type),
              const CancelButton()
            ],
          ),
        ),
      ),
    );
  }
}
