import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_states.dart';
import 'package:asma/Widgets/Shared_Widgets/circular_indicator.dart';
import '../../ViewModels/Cubit/Navigation/navigation_cubit.dart';
import '../../ViewModels/Cubit/Navigation/navigation_states.dart';
import '../../Widgets/Layout_Screen/floating_action_button.dart';

class LayoutScreen extends StatelessWidget {
  const LayoutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<NavigationCubit>(
      create: (_) => NavigationCubit(),
      child: BlocBuilder<NavigationCubit, NavigationStates>(
        builder: (context, state) {
          NavigationCubit navigationCubit = NavigationCubit.get(context);
          return Scaffold(
            body: BlocBuilder<MedicineCubit, MedicineStates>(
                buildWhen: (_, current) =>
                    current is PatientMedicineLoading ||
                    current is PatientMedicineLoaded,
                builder: (context, state) => state is PatientMedicineLoading
                    ? const CircularIndicator()
                    : navigationCubit
                        .navigationScreens[navigationCubit.currentIndex]),
            floatingActionButton: const FloatingActionButtonWidget(),
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerDocked,
            bottomNavigationBar: AnimatedBottomNavigationBar(
              activeColor: ConstantsClass.getDefaultColor(),
              gapLocation: GapLocation.center,
              icons: const [
                Icons.home_outlined,
                Icons.receipt_long_rounded,
                Icons.leaderboard_outlined,
                Icons.camera_alt_outlined,
              ],
              activeIndex: navigationCubit.currentIndex,
              onTap: (index) {
                navigationCubit.updateCurrentIndex(index);
              },
            ),
          );
        },
      ),
    );
  }
}
