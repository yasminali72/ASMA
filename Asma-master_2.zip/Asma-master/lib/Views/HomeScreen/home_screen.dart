import 'package:flutter/material.dart';
import 'package:asma/Widgets/Home_Screen/home_body_widget.dart';
import '../../Widgets/Home_Screen/home_top_buttons.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SafeArea(
      child: Column(
        children: [
          HomeTopButtons(),
          Expanded(child: HomeBodyWidget()),
        ],
      ),
    );
  }
}
