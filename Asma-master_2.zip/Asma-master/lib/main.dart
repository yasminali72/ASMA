import 'package:asma/Helpers/work_manager_helper.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:asma/Helpers/notification_helper.dart';
import 'package:asma/ViewModels/Constants/constants_class.dart';
import 'package:asma/ViewModels/Cubit/Medicine/medicine_cubit.dart';
import 'package:asma/ViewModels/Cubit/SignIn/sign_in_cubit.dart';
import 'package:asma/Widgets/Main/material_app_widget.dart';
import 'ViewModels/Cubit/Bloc_Observer/bloc_observer.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await LocalNotificationHelper.initialize();
  await WorkManagerHelper.init();
  Bloc.observer = MyBlocObserver();
  ConstantsClass.loadUId();

  SignInCubit signInCubit = SignInCubit();
  MedicineCubit medicineCubit = MedicineCubit();
  await signInCubit.getCurrentPatient();
  medicineCubit.getPatientMedicine(signInCubit.patient);
  runApp(MaterialAppWidget(
      signInCubit: signInCubit, medicineCubit: medicineCubit));
}
